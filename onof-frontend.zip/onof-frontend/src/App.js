import "./App.css";
import { useContext } from "react";
import GrantorSideActiveSchemes from "./Grantors/GrantorSideActiveSchemes/GrantorSideActiveSchemes";
import GrantorSideOpenSchemes from "./Grantors/GrantorSideOpenSchemes/GrantorSideOpenSchemes";
import GrantorSideSchemeApplications from "./Grantors/GrantorSideSchemeApplications/GrantorSideSchemeApplications";
import AboutUs from "./Pages/AboutContact/AboutUs";
import Contact from "./Pages/AboutContact/Contact";
import LandingDisplay from "./Pages/Landing/LandingDisplay";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import GrantorCurrentSchemeApplications from "./Grantors/GrantorCurrentSchemeApplications/GrantorCurrentSchemeApplications";
import ProjectDetails from "./ProjectDetails/ProjectDetails";
import GrantorSideScehemeDetails from "./Grantors/GrantorSideSchemeDetails/GrantorSideSchemeDetails";
import GrantorLogin from "./Grantors/GrantorLogin/GrantorLogin";
import GrantorSideSchemeProjects from "./Grantors/GrantorSideSchemeProjects/GrantorSideSchemeProjects";
import AuthContext from "./Store/AuthContext";
import GrantorRegister from "./Grantors/GrantorRegister/GrantorRegister";
import BeneficiariesSideSchemeListCard from "./Beneficiaries/BeneficiariesSideSchemeLists/BeneficiariesSideSchemeListCard";
import BeneficiariesSideSchemeList from "./Beneficiaries/BeneficiariesSideSchemeLists/BeneficiariesSideSchemeList";
import { Toaster } from "react-hot-toast";
import BeneficiariesSideSchemeDetails from "./Beneficiaries/BeneficiariesSideSchemeDetails/BeneficiariesSideSchemeDetails";
import BeneficiaryOngoingProjects from "./Beneficiaries/BeneficiaryOngoingProjects/BeneficiaryOngoingProjects";
import BeneficiaryLogin from "./Beneficiaries/BeneficiaryLogin/BeneficiaryLogin";
import BeneficiaryRegister from "./Beneficiaries/BeneficiaryRegister/BeneficiaryRegister";
import BeneficiaryFundApply from "./Beneficiaries/BeneficiaryFundApply/BeneficiaryFundApply";
import Applied from "./Beneficiaries/BeneficiaryFundApply/Applied";
import RefereeLogin from "./Referees/Referee Login/RefereeLogin";
import AllReferees from "./Referees/AllReferees/AllReferees";
import ApplicationsForReviews from "./Referees/ApplicationsForReviews/ApplicationsForReviews";
import ViewReviews from "./Referees/ViewReviews/ViewReviews";
import FollowPage from "./Beneficiaries/FollowPage/FollowPage";
import GrantorSidePastScheme from "./Grantors/GrantorSidePastScheme/GrantorSidePastScheme";
import AddSchemes from "./Grantors/AddSchemes/AddSchemes";
import Viewreports from "./Grantors/ViewReports/Viewreports";

function App() {
  const authCtx = useContext(AuthContext);
  return (
    <div className="App">
      {!authCtx.isLoggedIn && (
        <Router>
          <Routes>
            <Route path="/" element={<LandingDisplay />} exact />
            <Route path="RefereeLogin" element={<RefereeLogin />} exact />
            <Route path="/AboutUs" element={<AboutUs />} exact />
            <Route path="/Contact" element={<Contact />} exact />
            <Route path="GrantorRegister" element={<GrantorRegister />} exact />
            <Route path="GrantorLogin" element={<GrantorLogin />} exact />
            <Route
              path="BeneficiaryLogin"
              element={<BeneficiaryLogin />}
              exact
            />
            <Route
              path="BeneficiaryRegister"
              element={<BeneficiaryRegister />}
              exact
            />
            <Route path="*" element={<LandingDisplay />} exact />
          </Routes>
        </Router>
      )}

      {authCtx.isLoggedIn && authCtx.id == 0 && (
        // <Switch>

        <Router>
          <Routes>
            <Route path="AddSchemes" element={<AddSchemes />} exact />
            <Route path="FollowPage" element={<FollowPage />} exact />
            <Route
              path="GrantorSidePastScheme"
              element={<GrantorSidePastScheme />}
              exact
            />
            <Route path="Applied" element={<Applied />} exact />

            <Route path="AllReferees" element={<AllReferees />} exact />
            <Route
              path="ApplicationsForReviews"
              element={<ApplicationsForReviews />}
              exact
            />
            <Route path="ViewReviews" element={<ViewReviews />} exact />

            <Route
              path="/GrantorSideActiveSchemes"
              element={<GrantorSideActiveSchemes />}
              exact
            />

            <Route
              path="/GrantorSideSchemeApplications"
              element={<GrantorSideSchemeApplications />}
              exact
            />

            <Route
              path="/GrantorSideOpenSchemes"
              element={<GrantorSideOpenSchemes />}
              exact
            />

            <Route
              path="/GrantorSideScehemeDetails"
              element={<GrantorSideScehemeDetails />}
              exact
            />

            <Route
              path="/GrantorSideSchemeProjects"
              element={<GrantorSideSchemeProjects />}
              exact
            />

            <Route
              path="/GrantorCurrentSchemeApplications"
              element={<GrantorCurrentSchemeApplications />}
              exact
            />
            <Route path="/Viewreports" element={<Viewreports />} exact />
            <Route
              path="/GrantorSideScehemeDetails"
              element={<GrantorSideScehemeDetails />}
              exact
            />

            <Route path="ProjectDetails" element={<ProjectDetails />} exact />
            <Route path="*" element={<GrantorSideOpenSchemes />} />
          </Routes>
        </Router>
        // </Switch>
      )}

      {authCtx.isLoggedIn && authCtx.id == 1 && (
        <Router>
          <Routes>
            <Route path="/FollowPage" element={<FollowPage />} exact />
            <Route
              path="/BeneficiariesSideSchemeList"
              element={<BeneficiariesSideSchemeList />}
              exact
            />
            <Route path="/Viewreports" element={<Viewreports />} exact />
            <Route
              path="/BeneficiariesSideSchemeDetails"
              element={<BeneficiariesSideSchemeDetails />}
              exact
            />
            <Route
              path="/BeneficiaryOngoingProjects"
              element={<BeneficiaryOngoingProjects />}
              exact
            />
            <Route
              path="/BeneficiaryLogin"
              element={<BeneficiaryLogin />}
              exact
            />
            <Route
              path="/BeneficiaryRegister"
              element={<BeneficiaryRegister />}
              exact
            />
            <Route
              path="/BeneficiaryFundApply"
              element={<BeneficiaryFundApply />}
              exact
            />
            <Route path="Applied" element={<Applied />} exact />

            <Route path="AllReferees" element={<AllReferees />} exact />
            <Route
              path="ApplicationsForReviews"
              element={<ApplicationsForReviews />}
              exact
            />
            <Route path="ViewReviews" element={<ViewReviews />} exact />

            <Route path="ProjectDetails" element={<ProjectDetails />} exact />
            <Route path="*" element={<BeneficiariesSideSchemeList />} exact />
          </Routes>
        </Router>
      )}

      {authCtx.isLoggedIn && authCtx.id == 2 && (
        // <Switch>

        <Router>
          <Routes>
            <Route path="/Viewreports" element={<Viewreports />} exact />
            <Route path="Applied" element={<Applied />} />

            <Route path="AllReferees" element={<AllReferees />} />
            <Route
              path="ApplicationsForReviews"
              element={<ApplicationsForReviews />}
            />
            <Route path="ViewReviews" element={<ViewReviews />} />

            <Route
              path="/GrantorSideActiveSchemes"
              element={<GrantorSideActiveSchemes />}
            />

            <Route
              path="/GrantorSideSchemeApplications"
              element={<GrantorSideSchemeApplications />}
            />

            <Route
              path="/GrantorSideOpenSchemes"
              element={<GrantorSideOpenSchemes />}
            />

            <Route
              path="/GrantorSideScehemeDetails"
              element={<GrantorSideScehemeDetails />}
            />

            <Route
              path="/GrantorSideSchemeProjects"
              element={<GrantorSideSchemeProjects />}
            />

            <Route
              path="/GrantorCurrentSchemeApplications"
              element={<GrantorCurrentSchemeApplications />}
            />

            <Route
              path="GrantorSideScehemeDetails"
              element={<GrantorSideScehemeDetails />}
            />

            <Route path="ProjectDetails" element={<ProjectDetails />} />
          </Routes>
        </Router>
        // </Switch>
      )}

      <Toaster position="top-center" />
    </div>
  );
}

export default App;
