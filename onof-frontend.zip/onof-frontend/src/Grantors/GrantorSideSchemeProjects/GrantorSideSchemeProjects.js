import React from 'react'
import GrantorSideSchemeProjectsTable from './GrantorSideSchemeProjectsTable'
import './GrantorSideSchemeProjects.css';
import GrantorDashboard from '../GrantorDashboard/GrantorDashboard';


function GrantorSideSchemeProjects() {
    return (
        <div>

            <GrantorDashboard />
            Projects under our scheme

            <div className="schemeProjectsTable">
                <div className="schemeProjectsTableBox">
                    <GrantorSideSchemeProjectsTable />
                </div>

            </div>


        </div>
    )
}

export default GrantorSideSchemeProjects