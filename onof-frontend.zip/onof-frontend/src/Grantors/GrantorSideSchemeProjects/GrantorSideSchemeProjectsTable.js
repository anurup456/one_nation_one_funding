import React from 'react'
import './GrantorSideSchemeProjectsTable.css';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { useState, useEffect } from 'react';





function GrantorSideSchemeProjectsTable() {

    const [users, setUsers] = useState([]);

    const getUsers = async () => {
        const response = await fetch('');
        setUsers(await response.json());
    }
    useEffect(() => {
        getUsers();
    }, []);


    return (


        <div>
            {users.map(SchemeProjects => {
                return (


                    <TableContainer component={Paper}>
                        <Table id='tableProj' sx={{ minWidth: 700 }} aria-label="spanning table">
                            <TableHead>
                                <TableRow id='projTableTopRow'>
                                    <TableCell id='projTableTopRowText' align="center">
                                        Id:{SchemeProjects.Id}
                                    </TableCell>

                                    <TableCell id='projTableTopRowText'>S. No.</TableCell>
                                    <TableCell id='projTableTopRowText' align="left">Project</TableCell>
                                    <TableCell id='projTableTopRowText' align="left">Institute</TableCell>
                                    <TableCell id='projTableTopRowText' align="left">Contact</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>



                                <TableRow>
                                    <TableCell />
                                    <TableCell >{SchemeProjects.SNo}</TableCell>
                                    <TableCell align="left">{SchemeProjects.Project}</TableCell>
                                    <TableCell align="left">{SchemeProjects.Institute}</TableCell>
                                    <TableCell align="left">{SchemeProjects.Contact}</TableCell>
                                </TableRow>




                            </TableBody>
                        </Table>
                    </TableContainer>
                )
            })}
        </div>
    )
}

export default GrantorSideSchemeProjectsTable