import React, { useContext } from "react";
import "./AddSchemes.css";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import Box from "@mui/material/Box";
import Checkbox from "@mui/material/Checkbox";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import AddIcon from "@mui/icons-material/Add";
import { Button } from "@mui/material";
import Footer from "../../Components/Footer/Footer";
import { Image } from "react-bootstrap";
import GrantorDashboard from "../GrantorDashboard/GrantorDashboard";
import { useState } from "react";
import AuthContext from "../../Store/AuthContext";
import toast from "react-hot-toast";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const eligibilities = [
  { title: "Age below 18 Years" },
  { title: "Age below 25 Years" },
  { title: "Age below 35 Years" },
  { title: "NIRF Rank Below 100" },
  { title: "NIRF Rank Below 1000" },
  { title: "Research Experience Above 5 Years" },
  { title: "Only For Females" },
  { title: "NorthEast Quota" },
  { title: "PWD Quota" },
  { title: "SC Quota" },
  { title: "Family Income less Than 8LPA" },
  { title: "Army Quota" },
];

const tagsData = [
  { title: "Machine Learning" },
  { title: "Deep Learning" },
  { title: "Reinforcement Learning" },
  { title: "Aerospace" },
  { title: "Diseases" },
  { title: "Vaccine" },
  { title: "Virus" },
  { title: "Genetics" },
  { title: "Neuroscience" },
  { title: "Microbiology" },
  { title: "Biotechnology" },
  { title: "Astrophysics" },
  { title: "Medicine" },
  { title: "Engineering" },
  { title: "Stemcell" },
  { title: "Augmented Reality" },
  { title: "Zoology" },
  { title: "Pollution" },
  { title: "Eco Friendly" },
  { title: "Superphysiological" },
  { title: "Neural Network" },
  { title: "Gene Editing" },
  { title: "Ecology" },
  { title: "Biodiversity" },
  { title: "Materials Science" },
  { title: "Geology" },
  { title: "Chemistry" },
  { title: "Defence" },
];

function AddSchemes(props) {
  const authCtx = useContext(AuthContext);
  const [eligibility, setEligibility] = useState([]);
  const [name, setName] = useState("");
  const [applicationDeadline, setApplicationDeadline] = useState("");
  const [description, setDescription] = useState("");
  const [fundingLimit, setFundingLimit] = useState("");
  const [doc, setDoc] = useState(null);
  const [tags, setTags] = useState([]);

  const handleEligibilities = (e) => {
    if (e.target.checked === true) {
      setEligibility([...eligibility, e.target.value]);
    } else if (e.target.checked === false) {
      let freshArray = eligibility.filter((val) => val !== e.target.value);
      setEligibility([...freshArray]);
    }
  };

  const handleTags = (e) => {
    if (e.target.checked === true) {
      setTags([...tags, e.target.value]);
    } else if (e.target.checked === false) {
      let freshArray = tags.filter((val) => val !== e.target.value);
      setTags([...freshArray]);
    }
  };

  const handleSubmit = () => {
    console.log(tags);
    const formData = new FormData();
    formData.append("file", doc);
    formData.append("name", name);
    formData.append("applicationDeadline", applicationDeadline);
    formData.append("description", description);
    formData.append("fundingLimit", fundingLimit);
    formData.append("tags", tags);
    formData.append("eligibility", eligibility);
    formData.append("document", doc.name);
    fetch("http://localhost:8080/scheme/addScheme/" + authCtx.userId, {
      method: "POST",
      body: formData,
    })
      .then((res) => {
        if (res.ok) {
          return res.json();
        } else {
          return res.json().then((data) => {
            let errorMessage = data.message;

            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
            }

            throw new Error(errorMessage);
          });
        }
      })

      .then((data) => {
        toast.success(data.message);
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };

  return (
    <div>
      <GrantorDashboard />

      <span className="addS">ADD SCHEMES</span>

      <div className="addSchemesContainer">
        <div className="addSchemesContainerBox1">
          <div className="addSchemesForm">
            <TextField
              onChange={(event) => setName(event.target.value)}
              id="outlined-password-input"
              label="Scheme Title"
              type="text"
              autoComplete="current-password"
            />

            <Autocomplete
              multiple
              id="checkboxes-tags-demo"
              options={eligibilities}
              disableCloseOnSelect
              getOptionLabel={(option) => option.title}
              renderOption={(props, option, { selected }) => (
                <li {...props}>
                  <Checkbox
                    value={option.title}
                    icon={icon}
                    checkedIcon={checkedIcon}
                    onChange={handleEligibilities}
                    style={{ marginRight: 8 }}
                    checked={selected}
                  />
                  {option.title}
                </li>
              )}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Eligibility Criteria"
                  placeholder="Eligibility Criteria"
                />
              )}
            />

            <Autocomplete
              multiple
              id="checkboxes-tags-demo"
              options={tagsData}
              disableCloseOnSelect
              getOptionLabel={(option) => option.title}
              renderOption={(props, option, { selected }) => (
                <li {...props}>
                  <Checkbox
                    value={option.title}
                    icon={icon}
                    checkedIcon={checkedIcon}
                    style={{ marginRight: 8 }}
                    checked={selected}
                    onChange={handleTags}
                  />
                  {option.title}
                </li>
              )}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Add Tags"
                  placeholder="Add Tags"
                />
              )}
            />

            <TextField
              onChange={(event) => setApplicationDeadline(event.target.value)}
              id="outlined-password-input"
              label="Application Deadline"
              type="text"
              autoComplete="current-password"
            />

            <TextField
              onChange={(event) => setFundingLimit(event.target.value)}
              id="outlined-password-input"
              label="Approved Budget Limit"
              type="text"
              autoComplete="current-password"
            />

            <TextField
              onChange={(event) => setDescription(event.target.value)}
              id="outlined-password-input1"
              label="Description"
              type="text"
              multiline
              autoComplete="current-password"
            />

            <TextField
              onChange={(event) => {
                setDoc(event.target.files[0]);
              }}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              defaultValue=""
              type="file"
              id="outlined-password-input"
            />

            <Button
              onClick={handleSubmit}
              id="btnAdd"
              variant="contained"
              component="label"
            >
              Submit
            </Button>
          </div>
        </div>
        <div className="addSchemesContainerBox2">
          <div className="imgBox">
            <Image
              className="logo"
              src="Images/undraw_add_files_re_v09g.svg"
              alt="logo0"
            />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default AddSchemes;
