import React from "react";
import Footer from "../../Components/Footer/Footer";
import GrantorDashboard from "../GrantorDashboard/GrantorDashboard";
import GrantorSideOpenSchemeCard from "./GrantorSideOpenSchemeCard";

function GrantorSideOpenSchemes() {
  return (
    <div>
      <div>
        <GrantorDashboard />
        <div className="listContainer">
          <div className="listBox">
            <GrantorSideOpenSchemeCard />
          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
}

export default GrantorSideOpenSchemes;
