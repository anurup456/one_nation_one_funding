import React, { useContext } from "react";
import "./GrantorSideOpenSchemeCard.css";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import AuthContext from "../../Store/AuthContext";
import AppState from "../../Store/AppState";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import InputBase from "@mui/material/InputBase";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import { styled, alpha } from "@mui/material/styles";

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 1),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 1),
  },
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(1),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "left",
  justifyContent: "left",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  display: "flex",
  alignItems: "left",
  justifyContent: "left",
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      width: "12ch",
      "&:focus": {
        width: "20ch",
      },
    },
  },
}));

function GrantorSideOpenSchemeCard() {
  let navigate = useNavigate();
  const authCtx = useContext(AuthContext);
  const appState = useContext(AppState);
  const [search, setSearch] = useState("");
  const [users, setUsers] = useState([]);

  const getUsers = async () => {
    fetch(
      "http://localhost:8080/scheme/postedSchemes/" +
        authCtx.userId +
        "/" +
        search
    )
      .then((res) => {
        return res.json();
      })
      .then((data) => setUsers(data));
  };

  useEffect(() => {
    getUsers();
  }, [search]);

  return (
    <div>
      <Card id="cardTop">
        <CardActionArea>
          <CardContent id="cardTopHead">
            <Button style={{ color: "white" }} variant="text">
              scheme Id
            </Button>
            <Button style={{ color: "white" }} variant="text">
              Scheme Title
            </Button>
            <Button style={{ color: "white" }} variant="text">
              Applicants
            </Button>
          </CardContent>
        </CardActionArea>
      </Card>
      <Search className="searchh">
        <SearchIconWrapper>
          <SearchIcon />
        </SearchIconWrapper>
        <StyledInputBase
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search…"
          inputProps={{ "aria-label": "search" }}
        />
      </Search>
      <div className="cardLists">
        {users.map((OpenScheme) => {
          return (
            <Card id="cardListsS">
              <CardActionArea>
                <CardContent id="cardListsSHead">
                  <Button variant="text">{OpenScheme.psID}</Button>
                  <Button
                    variant="text"
                    onClick={() => {
                      appState.setSchemeId(OpenScheme._id);
                      navigate("/GrantorSideScehemeDetails");
                    }}
                  >
                    {OpenScheme.name}
                  </Button>
                  <Button
                    variant="outlined"
                    onClick={() => {
                      appState.setSchemeId(OpenScheme._id);
                      navigate("/GrantorCurrentSchemeApplications");
                    }}
                  >
                    {OpenScheme.postedApplications
                      ? OpenScheme.postedApplications.length
                      : 0}
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default GrantorSideOpenSchemeCard;
