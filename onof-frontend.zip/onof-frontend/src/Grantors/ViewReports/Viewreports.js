import React from "react";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import "./Viewreports.css";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Footer from "../../Components/Footer/Footer";
import TextField from "@mui/material/TextField";

import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 600,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function Viewreports() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <div>
      <Bar />
      <HeroSection />
      <div className="repBox">
        <div className="repBoxContainer">
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableBody>
                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell className="tb" component="th" scope="row">
                    Applied on:
                  </TableCell>
                  <TableCell align="left">26-08-2022</TableCell>
                  <TableCell align="left">
                    {" "}
                    <Button variant="contained">View Report</Button>
                  </TableCell>
                </TableRow>

                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell className="tb" component="th" scope="row">
                    Reviewed on:
                  </TableCell>
                  <TableCell align="left">26-08-2022</TableCell>
                  <TableCell align="left">
                    {" "}
                    <Button variant="contained">View Report</Button>
                  </TableCell>
                </TableRow>

                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell className="tb" component="th" scope="row">
                    Accepted on:
                  </TableCell>
                  <TableCell align="left">26-08-2022</TableCell>
                  <TableCell align="left">
                    {" "}
                    <Button variant="contained">View Report</Button>
                  </TableCell>
                </TableRow>

                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell className="tb" component="th" scope="row">
                    Referee assigned on:
                  </TableCell>
                  <TableCell align="left">26-08-2022</TableCell>
                  <TableCell align="left">
                    {" "}
                    <Button variant="contained">View Report</Button>
                  </TableCell>
                </TableRow>

                <TableRow
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell className="tb" component="th" scope="row">
                    Referee assigned on:
                  </TableCell>
                  <TableCell align="left">26-08-2022</TableCell>
                  <TableCell align="left">
                    {" "}
                    <Button variant="contained">View Report</Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </div>
      <Button onClick={handleOpen} id="sm" variant="contained">
        Schedule Meet
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            <TextField
              className="tmm"
              id="outlined-password-input"
              label="Meet link"
              type="Meet link"
              autoComplete="current-password"
            />
            <TextField
              className="tmm"
              id="outlined-password-input"
              type="Date"
              autoComplete="current-password"
            />
            <TextField id="tmm" type="time" autoComplete="current-password" />
          </Typography>
          <Button onClick={handleOpen} id="sm" variant="contained">
            Submit
          </Button>
        </Box>
      </Modal>
      <Footer />
    </div>
  );
}

export default Viewreports;
