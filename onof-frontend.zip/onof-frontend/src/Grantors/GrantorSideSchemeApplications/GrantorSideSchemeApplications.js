import React from 'react'
import GrantorDashboard from '../GrantorDashboard/GrantorDashboard'
import GrantorSideSchemeApplicationsCard from './GrantorSideSchemeApplicationsCard'
import './GrantorSideSchemeApplications.css';
import Footer from '../../Components/Footer/Footer';

function GrantorSideSchemeApplications() {
    return (
        <div>
            <GrantorDashboard />
            <div className="listContainer">
                <div className="listBox">
                    <GrantorSideSchemeApplicationsCard />
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default GrantorSideSchemeApplications