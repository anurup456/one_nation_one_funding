import React, { useContext } from "react";
import "./GrantorCurrentSchemeApplicationsCards.css";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import AppState from "../../Store/AppState";
import toast from "react-hot-toast";

function GrantorCurrentSchemeApplicationsCard({ applications }) {
  let navigate = useNavigate();

  const appState = useContext(AppState);
  return (
    <div>
      <Card id="cardTop">
        <CardActionArea>
          <CardContent id="cardTopHead">
            <Button style={{ color: "white" }} variant="text">
              Id
            </Button>
            <Button
              style={{ color: "white" }}
              className="topText"
              variant="text"
            >
              Project
            </Button>
            <Button
              style={{ color: "white" }}
              className="topText"
              variant="text"
            >
              Reviewer
            </Button>
            <Button
              style={{ color: "white" }}
              className="topText"
              variant="text"
            >
              Review
            </Button>
            <Button
              style={{ color: "white" }}
              className="topText"
              variant="text"
            >
              Decision
            </Button>
          </CardContent>
        </CardActionArea>
      </Card>

      <div className="cardLists">
        {applications.map((CurrentSchemeApplications) => {
          return (
            <Card id="cardListsS">
              <CardActionArea>
                <CardContent id="cardListsSHead">
                  <Button className="cardBtnTxt" variant="text">
                    {CurrentSchemeApplications.applicationId}
                  </Button>
                  <Button
                    onClick={() => {
                      navigate("/ProjectDetails");
                    }}
                    className="cardBtnTxt"
                    variant="text"
                  >
                    {CurrentSchemeApplications.title}
                  </Button>
                  {!CurrentSchemeApplications.reviewer && (
                    <Button
                      id="cardBtnTxt"
                      variant="outlined"
                      onClick={() => {
                        appState.setApplicationId(
                          CurrentSchemeApplications._id
                        );
                        navigate("/AllReferees");
                      }}
                    >
                      Appoint
                    </Button>
                  )}
                  {CurrentSchemeApplications.reviewer && <>Appointed</>}
                  <Button
                    onClick={() => {
                      fetch(
                        "http://localhost:8080/grantor/reviewDocs/" +
                          appState.applicationId +
                          "/" +
                          CurrentSchemeApplications.reviewer
                      )
                        .then((res) => {
                          return res.blob();
                        })
                        .then((blob) => {
                          const file = new Blob([blob], {
                            type: "application/pdf",
                          });
                          const fileURL = URL.createObjectURL(file);
                          const pdfWindow = window.open();
                          pdfWindow.location.href = fileURL;
                        });
                    }}
                    id="instt"
                    variant="outlined"
                  >
                    View
                  </Button>
                  <div className="decide">
                    <div className="decide1">
                      <Button
                        onClick={() => {
                          fetch(
                            "http://localhost:8080/application/acceptApplication/" +
                              CurrentSchemeApplications._id,
                            {
                              method: "POST",
                            }
                          )
                            .then((res) => {
                              return res.json();
                            })
                            .then((data) => toast.success(data.message));
                        }}
                        variant="outlined"
                      >
                        Accept
                      </Button>
                      <Button
                        onClick={() => {
                          fetch(
                            "http://localhost:8080/application/rejectApplication/" +
                              CurrentSchemeApplications._id,
                            {
                              method: "POST",
                            }
                          )
                            .then((res) => {
                              return res.json();
                            })
                            .then((data) => toast.success(data.message));
                        }}
                        variant="outlined"
                      >
                        Reject
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </CardActionArea>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default GrantorCurrentSchemeApplicationsCard;
