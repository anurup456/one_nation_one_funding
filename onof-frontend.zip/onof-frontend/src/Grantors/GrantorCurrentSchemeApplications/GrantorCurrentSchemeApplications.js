import React, { useContext, useEffect, useState } from "react";
import Footer from "../../Components/Footer/Footer";
import AppState from "../../Store/AppState";
import GrantorDashboard from "../GrantorDashboard/GrantorDashboard";
import GrantorCurrentSchemeApplicationsCard from "./GrantorCurrentSchemeApplicationsCard";

function GrantorCurrentSchemeApplications() {
  const appState = useContext(AppState);
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    fetch(
      "http://localhost:8080/scheme/postedApplications/" + appState.schemeId
    )
      .then((res) => {
        return res.json();
      })
      .then((data) => setApplications(data));
  }, []);

  return (
    <div>
      <div>
        <GrantorDashboard />
        <div className="listContainer">
          <div className="listBox">
            <GrantorCurrentSchemeApplicationsCard applications={applications} />
          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
}

export default GrantorCurrentSchemeApplications;
