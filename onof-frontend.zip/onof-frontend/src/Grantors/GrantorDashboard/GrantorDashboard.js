import React, { useEffect, useContext, useState } from "react";
import Bar from "../../Components/Navbar/Navbar";
import "./GrantorDashboard.css";
import { useNavigate } from "react-router-dom";
import AuthContext from "../../Store/AuthContext";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import toast from "react-hot-toast";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function GrantorDashboard() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [designation, setDesignation] = useState("");
  const [affiliation, setAffiliation] = useState("");

  let navigate = useNavigate();
  const authCtx = useContext(AuthContext);
  const [grantor, setGrantor] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/grantor/grantorDetails/" + authCtx.userId)
      .then((res) => {
        return res.json();
      })
      .then((data) => setGrantor(data));
  }, []);

  const handleSubmit = () => {
    fetch("http://localhost:8080/referee/addReferee/" + authCtx.userId, {
      method: "POST",
      body: JSON.stringify({
        email: email,
        name: name,
        designation: designation,
        institute: affiliation,
      }),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => {
        if (res.ok) {
          return res.json();
        } else {
          return res.json().then((data) => {
            let errorMessage = data.message;

            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
            }

            throw new Error(errorMessage);
          });
        }
      })

      .then((data) => {
        toast.success(data.message);
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };
  return (
    <div>
      <Bar />
      <div className="dashContainer">
        <div className="dashTopBox">
          <div className="dashTopInsttName">{grantor.name}</div>
          <div className="dashTopInsttAdd">{grantor.address}</div>
        </div>

        <div className="dashContBox">
          <div className="dashCont">
            <div className="dashOptionsBox1">
              <Button
                id="dashBtn"
                variant="contained"
                onClick={() => {
                  navigate("/GrantorSidePastScheme");
                }}
              >
                Past Schemes
              </Button>
              <Button
                onClick={() => {
                  navigate("/GrantorSideOpenSchemes");
                }}
                id="dashBtn"
                variant="contained"
              >
                Open Schemes
              </Button>

              <Button
                onClick={() => {
                  navigate("/GrantorSideActiveSchemes");
                }}
                id="dashBtn"
                variant="contained"
              >
                Active Schemes
              </Button>
            </div>

            <div className="dashOptionsBox2">
              <div className="dashOptionsBox1">
                <Button
                  onClick={() => {
                    navigate("/AddSchemes");
                  }}
                  id="dashBtn"
                  variant="contained"
                >
                  Add Schemes
                </Button>

                <Button onClick={handleOpen} id="dashBtn" variant="contained">
                  Add Reviewer
                </Button>
                <Modal
                  id="mod"
                  open={open}
                  onClose={handleClose}
                  aria-labelledby="modal-modal-title"
                  aria-describedby="modal-modal-description"
                >
                  <Box sx={style}>
                    <Typography
                      id="modal-modal-title"
                      variant="h6"
                      component="h2"
                    >
                      <TextField
                        onChange={(event) => setName(event.target.value)}
                        id="bt"
                        label="Name"
                        type="text"
                        autoComplete="current-password"
                      />

                      <TextField
                        id="bt"
                        onChange={(event) => setAffiliation(event.target.value)}
                        label="Affiliation"
                        type="text"
                        autoComplete="current-password"
                      />

                      <TextField
                        onChange={(event) => setDesignation(event.target.value)}
                        id="bt"
                        label="Designation"
                        type="text"
                        autoComplete="current-password"
                      />

                      <TextField
                        onChange={(event) => setEmail(event.target.value)}
                        id="bt"
                        label="Email"
                        type="text"
                        autoComplete="current-password"
                      />
                    </Typography>

                    <Button
                      fullWidth
                      variant="contained"
                      onClick={handleSubmit}
                    >
                      Submit
                    </Button>
                  </Box>
                </Modal>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GrantorDashboard;
