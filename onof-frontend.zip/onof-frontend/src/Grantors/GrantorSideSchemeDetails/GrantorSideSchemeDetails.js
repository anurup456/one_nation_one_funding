import React, { useState, useEffect } from "react";
import Footer from "../../Components/Footer/Footer";
import Bar from "../../Components/Navbar/Navbar";
import GrantorSideSchemeDetailsTable from "./GrantorSideSchemeDetailsTable";
import { useContext } from "react";
import AppState from "../../Store/AppState";

function GrantorSideScehemeDetails() {
  const appState = useContext(AppState);
  console.log(appState);

  const [scheme, setScheme] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/scheme/schemeDetails/" + appState.schemeId)
      .then((res) => {
        return res.json();
      })
      .then((data) => setScheme(data));
  }, []);

  return (
    <div>
      <Bar />
      <div className="dashTopBox">
        <div className="dashTopInsttName">{scheme.name}</div>
        <div className="dashTopInsttAdd">{scheme.address}</div>
      </div>
      <div className="projectDetailsTable">
        <div className="projectDetailsTableBox">
          <GrantorSideSchemeDetailsTable scheme={scheme} />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default GrantorSideScehemeDetails;
