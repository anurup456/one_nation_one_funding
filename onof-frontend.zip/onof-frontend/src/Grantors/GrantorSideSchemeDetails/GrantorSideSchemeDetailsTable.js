import React, { useState, useEffect } from "react";
import "./GrantorSideSchemeDetailsTable.css";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

function GrantorSideSchemeDetailsTable({ scheme }) {
  return (
    <div>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead id="tableProj">
            <TableRow>
              <TableCell id="schemeMainDetail">Description</TableCell>
              <TableCell id="schemeMainDetailContent" align="left">
                {scheme.description}
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell id="schemeMainDetail">Eligibility</TableCell>
              <TableCell id="schemeMainDetailContent" align="left">
                {scheme.eligibility}
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell id="schemeMainDetail">Funding</TableCell>
              <TableCell id="schemeMainDetailContent" align="left">
                {scheme.fundingLimit}
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell id="schemeMainDetail">Proposal Format</TableCell>
              <TableCell id="schemeMainDetailContent" align="left">
                {scheme.document}
              </TableCell>
            </TableRow>
          </TableHead>
        </Table>
      </TableContainer>
    </div>
  );
}

export default GrantorSideSchemeDetailsTable;
