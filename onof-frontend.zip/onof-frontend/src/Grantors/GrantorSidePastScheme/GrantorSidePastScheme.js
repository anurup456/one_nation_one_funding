import React from "react";
import GrantorDashboard from "../GrantorDashboard/GrantorDashboard";
import GrantorSidePastSchemeCards from "./GrantorSidePastSchemeCards";
import "./GrantorSidePastScheme.css";
import Footer from "../../Components/Footer/Footer";

function GrantorSidePastScheme() {
  return (
    <div>
      <GrantorDashboard />
      <div className="listContainer">
        <div className="listBox">
          <GrantorSidePastSchemeCards />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default GrantorSidePastScheme;
