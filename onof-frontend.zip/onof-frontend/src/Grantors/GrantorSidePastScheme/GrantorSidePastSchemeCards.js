import React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import "./GrantorSidePastSchemeCards.css";
import { useState, useEffect } from "react";

function GrantorSidePastSchemeCards() {
  const [users, setUsers] = useState([]);

  const getUsers = async () => {
    const response = await fetch("");
    setUsers(await response.json());
  };
  useEffect(() => {
    getUsers();
  }, []);
  return (
    <div>
      <Card id="cardTop">
        <CardActionArea>
          <CardContent id="cardTopHeadPast">
            <Button id="cardTopHeadP" variant="text">
              scheme Id
            </Button>
            <Button id="cardTopHeadP" variant="text">
              Scheme Title
            </Button>
            <Button id="cardTopHeadP" variant="text">
              Applicants
            </Button>
          </CardContent>
        </CardActionArea>
      </Card>

      <div className="cardLists">
        {users.map((Past) => {
          return (
            <Card id="cardListsS">
              <CardActionArea>
                <CardContent id="cardListsSHead">
                  <Button variant="text">{Past.SchemeId}</Button>
                  <Button variant="text">{Past.SchemeTitle}</Button>
                  <Button variant="outlined">{Past.Applicants}</Button>
                </CardContent>
              </CardActionArea>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default GrantorSidePastSchemeCards;
