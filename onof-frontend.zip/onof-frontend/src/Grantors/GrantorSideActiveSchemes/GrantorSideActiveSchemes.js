import React from "react";
import Footer from "../../Components/Footer/Footer";
import GrantorDashboard from "../GrantorDashboard/GrantorDashboard";
import GrantorSideActiveSchemesCard from "./GrantorSideActiveSchemesCard";

function GrantorSideActiveSchemes() {
  return (
    <div>
      <div>
        <GrantorDashboard />
        <div className="listContainer">
          <div className="listBox">
            <GrantorSideActiveSchemesCard />
          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
}

export default GrantorSideActiveSchemes;
