import React from "react";
import "./GrantorSideActiveSchemesCard.css";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

function GrantorSideActiveSchemesCard() {
  let navigate = useNavigate();

  const [users, setUsers] = useState([]);

  const getUsers = async () => {
    const response = await fetch("");
    setUsers(await response.json());
  };
  useEffect(() => {
    getUsers();
  }, []);

  return (
    <div>
      <Card id="cardTop">
        <CardActionArea>
          <CardContent id="cardTopHead">
            <Button id="cardTopHeadText" variant="text">
              Scheme Id
            </Button>
            <Button id="cardTopHeadText" variant="text">
              Scheme Title
            </Button>
            <Button id="cardTopHeadText" variant="text">
              Beneficiary
            </Button>
            <Button id="cardTopHeadText" variant="text">
              Updates
            </Button>
          </CardContent>
        </CardActionArea>
      </Card>

      <div className="cardLists">
        {/* {users.map((ActiveSchemes) => {
          return ( */}
            <Card id="cardListsS">
              <CardActionArea>
                <CardContent id="cardListsSHead">
                  <Button variant="text">1235</Button>
                  <Button
                    id="btnCardList1"
                    variant="outline"
                    onClick={() => {
                      navigate("/GrantorSideScehemeDetails");
                    }}
                  >
                   Yojna Hind
                  </Button>
                  <Button id="btnCardList" variant="outline">
                    1
                  </Button>
                  <Button
                    id="btnCardList1"
                    variant="outline"
                    onClick={() => {
                      navigate("/Viewreports");
                    }}
                  >
                    Updates
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>

            <Card id="cardListsS">
              <CardActionArea>
                <CardContent id="cardListsSHead">
                  <Button variant="text">1235</Button>
                  <Button
                    id="btnCardList1"
                    variant="outline"
                    onClick={() => {
                      navigate("/GrantorSideScehemeDetails");
                    }}
                  >
                   Yojna Hind
                  </Button>
                  <Button id="btnCardList" variant="outline">
                    1
                  </Button>
                  <Button
                    id="btnCardList1"
                    variant="outline"
                    onClick={() => {
                      navigate("/Viewreports");
                    }}
                  >
                    Updates
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>

            <Card id="cardListsS">
              <CardActionArea>
                <CardContent id="cardListsSHead">
                  <Button variant="text">1235</Button>
                  <Button
                    id="btnCardList1"
                    variant="outline"
                    onClick={() => {
                      navigate("/GrantorSideScehemeDetails");
                    }}
                  >
                   Yojna Hind
                  </Button>
                  <Button id="btnCardList" variant="outline">
                    1
                  </Button>
                  <Button
                    id="btnCardList1"
                    variant="outline"
                    onClick={() => {
                      navigate("/Viewreports");
                    }}
                  >
                    Updates
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          {/* );
        })} */}
      </div>
    </div>
  );
}

export default GrantorSideActiveSchemesCard;
