import React, { useState } from "react";
import Bar from "../../Components/Navbar/Navbar";
import "./BeneficiaryLogin.css";
import { useNavigate } from "react-router-dom";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import { Image } from "react-bootstrap";
import Button from "@mui/material/Button";
import Footer from "../../Components/Footer/Footer";
import { useContext } from "react";
import toast from "react-hot-toast";
// import AuthContext, { AuthContextProvider } from '../Store/AuthContext'
import { Toaster } from "react-hot-toast";
import TextField from "@mui/material/TextField";
import AuthContext, { AuthContextProvider } from "../../Store/AuthContext";

function BeneficiaryLogin() {
  let navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const authCtx = useContext(AuthContext);

  const handleLoginSubmit = (event) => {
    event.preventDefault();
    fetch("http://localhost:8080/institute/login/", {
      method: "POST",
      body: JSON.stringify({
        email: email,
        password: password,
        returnSecureToken: true,
      }),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => {
        if (res.ok) {
          return res.json();
        } else {
          return res.json().then((data) => {
            let errorMessage = data.message;

            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
            }

            throw new Error(errorMessage);
          });
        }
      })

      .then((data) => {
        toast.success(data.message);
        if (data.data) {
          navigate("/BeneficiariesSideSchemeList");
          authCtx.login({
            accessToken: data.data,
            email: email,
            id: 1,
            userId: data.userId,
          });
        }
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };

  return (
    <div>
      <Bar />
      <HeroSection />

      <div className="grantorLogin">
        <p className="loginTxt">Institute Log In </p>
        <div className="grantorLoginBox">
          <div className="grantorLoginBox1">
            <TextField
              onChange={(event) => setEmail(event.target.value)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Email"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setPassword(event.target.value)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Password"
              type="password"
              autoComplete="current-password"
            />

            <br />
            <Button onClick={handleLoginSubmit} id="lgnBtn" variant="contained">
              Login
            </Button>
          </div>

          <div className="grantorLoginBox2">
            <div className="imggHolder">
              <Image
                className="logo"
                src="Images/undraw_education_f8ru.svg"
                alt="logo0"
              />
              <br />
              Say hello to a brighter tomorrow!
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default BeneficiaryLogin;
