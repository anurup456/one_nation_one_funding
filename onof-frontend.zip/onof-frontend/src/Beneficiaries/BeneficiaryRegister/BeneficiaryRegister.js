import React from "react";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import "./BeneficiaryRegister.css";
import { Button } from "@mui/material";
import { Image } from "react-bootstrap";
import Footer from "../../Components/Footer/Footer";
import TextField from "@mui/material/TextField";
import { useState } from "react";
import toast from "react-hot-toast";

function BeneficiaryRegister(props) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [password, setPassword] = useState("");
  const [head, setHead] = useState("");
  const [code, setCode] = useState("");
  const [poc, setPoc] = useState("");
  const [doc, setDoc] = useState(null);

  const handleRegisterSubmit = (event) => {
    const formData = new FormData();
    formData.append("file", doc);
    formData.append("name", name);
    formData.append("email", email);
    formData.append("address", address);
    formData.append("password", password);
    formData.append("head", head);
    formData.append("code", code);
    formData.append("poc", poc);
    formData.append("document", doc.name);
    fetch("http://localhost:8080/institute/register", {
      method: "POST",
      body: formData,
    })
      .then(async (res) => {
        if (res.ok) {
          return res.json();
        } else {
          const data = await res.json();
          let errorMessage = data.message;
          if (data && data.error && data.error.message) {
            errorMessage = data.error.message;
          }
          throw new Error(errorMessage);
        }
      })
      .then((data) => {
        toast.success("Verification Mail Sent");
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };

  return (
    <div>
      <Bar />
      <HeroSection />

      <div className="grantorLogin">
        <p className="loginTxt"> Institute Registration </p>
        <div className="grantorLoginBox">
          <div className="grantorLoginBox1">
            <TextField
              onChange={(event) => setName(event.target.value)}
              style={{ marginTop: "30px", marginBottom: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Name"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setEmail(event.target.value)}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Email"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setAddress(event.target.value)}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Base of Operation"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setCode(event.target.value)}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Institute Code"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setHead(event.target.value)}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Head of Institute"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setPoc(event.target.value)}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Point Of Contact"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => {
                setDoc(event.target.files[0]);
              }}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              defaultValue=""
              type="file"
              id="outlined-required"
            />
            <TextField
              onChange={(event) => setPassword(event.target.value)}
              style={{ margin: "20px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Password"
              type="password"
              autoComplete="current-password"
            />

            <Button
              onClick={handleRegisterSubmit}
              id="lgnBtn"
              variant="contained"
            >
              Sign Up
            </Button>
          </div>

          <div className="grantorLoginBox2" id="grantorReginBox2">
            <div className="imggHolder">
              <Image
                id="regImg"
                className="logo"
                src="Images/undraw_education_f8ru.svg"
                alt="logo0"
              />
              <br />
              <p id="regTxt">Hello to a brighter tomorrow!</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default BeneficiaryRegister;
