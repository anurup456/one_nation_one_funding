import React, { useContext } from "react";
import "./BeneficiariesSideSchemeListcard.css";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import AppState from "../../Store/AppState";

function BeneficiariesSideSchemeListCard() {
  let navigate = useNavigate();
  const appState = useContext(AppState);
  const [schemes, setSchemes] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/scheme/allSchemes")
      .then((res) => {
        return res.json();
      })
      .then((data) => setSchemes(data));
  }, []);

  return (
    <div className="beneciaryCardBoxCon">
      <div className="beneciaryCardBox">
        <Card>
          <CardActionArea>
            <CardContent className="beneciaryCard">
              <Button id="benefiaciaryBtn">Id.</Button>
              <Button id="benefiaciaryBtn">Scheme Title</Button>
              <Button id="benefiaciaryBtn">Grantor</Button>
              <Button id="benefiaciaryBtn">Deadline</Button>
              <Button id="benefiaciaryBtn">Apply</Button>
            </CardContent>
          </CardActionArea>
        </Card>

        {schemes.map((SchemeList) => {
          return (
            <Card>
              <CardActionArea>
                <CardContent className="beneciaryCardContent">
                  <Button className="benefiaciarylistBtn">
                    {SchemeList.psID}
                  </Button>
                  <Button
                    onClick={() => {
                      appState.setSchemeId(SchemeList._id);
                      navigate("/BeneficiariesSideSchemeDetails ");
                    }}
                    className="benefiaciarylistBtn"
                  >
                    {" "}
                    {SchemeList.name}
                  </Button>

                  <Button className="benefiaciarylistBtn">
                    {SchemeList.grantorName}
                  </Button>
                  <Button className="benefiaciarylistBtn">
                    {SchemeList.applicationDeadline}
                  </Button>
                  <Button
                    onClick={() => {
                      appState.setSchemeId(SchemeList._id);
                      navigate("/BeneficiaryFundApply ");
                    }}
                    className="benefiaciaryBtn"
                  >
                    Apply
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default BeneficiariesSideSchemeListCard;
