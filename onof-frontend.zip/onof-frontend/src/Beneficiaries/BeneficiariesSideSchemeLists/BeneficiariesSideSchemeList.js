import React from "react";
import BeneficiariesDashboard from "../BeneficiariesDashboard/BeneficiariesDashboard";
import BeneficiariesSideSchemeListCard from "./BeneficiariesSideSchemeListCard";
import "./BeneficiariesSideSchemeList.css";
import Footer from "../../Components/Footer/Footer";

function BeneficiariesSideSchemeList() {
  return (
    <div>
      <BeneficiariesDashboard />
      <div className="BeneficiariesSideSchemeListCardCon">
        <div className="topTextBeneficiarySides">Schemes</div>

        <BeneficiariesSideSchemeListCard />
      </div>
      <Footer />
    </div>
  );
}

export default BeneficiariesSideSchemeList;
