import React from "react";
import "./BeneficiaryFundApply.css";
import { useNavigate } from "react-router-dom";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import { Button } from "@mui/material";
import { Image } from "react-bootstrap";
import Footer from "../../Components/Footer/Footer";
import TextField from "@mui/material/TextField";
import { useState, useContext } from "react";
import clsx from "clsx";
// import { useHistory } from "react-router-dom";
import toast from "react-hot-toast";
import AuthContext, { AuthContextProvider } from "../../Store/AuthContext";
import AppState from "../../Store/AppState";

function BeneficiaryFundApply() {
  let navigate = useNavigate();
  const authCtx = useContext(AuthContext);
  const appState = useContext(AppState);
  // const history = useHistory();
  console.log(appState);
  const [title, setTitle] = useState("");
  const [email, setEmail] = useState("");
  const [estimatedBudget, setEstimatedBudget] = useState("");

  const [details, setDetails] = useState("");
  const [lead, setLead] = useState("");
  const [doc, setDoc] = useState("");

  const handleSubmit = (event) => {
    const formData = new FormData();
    formData.append("file", doc);
    formData.append("title", title);
    formData.append("details", details);
    formData.append("lead", lead);
    formData.append("estimatedBudget", estimatedBudget);
    formData.append("document", doc.name);
    event.preventDefault();
    fetch(
      "http://localhost:8080/application/newApplication/" +
        authCtx.userId +
        "/" +
        appState.schemeId,
      {
        method: "POST",
        body: formData,
      }
    )
      .then((res) => {
        if (res.ok) {
          return res.json();
        } else {
          return res.json().then((data) => {
            let errorMessage = data.message;

            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
            }

            throw new Error(errorMessage);
          });
        }
      })
      .then((data) => {
        toast.success("Application Submitted Successfully!");
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };

  return (
    <div>
      <Bar />
      <HeroSection />

      <div className="grantorLogin">
        <p className="loginTxt"> Apply For Schemes </p>
        <div className="grantorLoginBox">
          <div className="grantorLoginBox1">
            <TextField
              onChange={(event) => setTitle(event.target.value)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Project Title"
              type="text"
              autoComplete="current-password"
            />

            <TextField
              multiline
              onChange={(event) => setDetails(event.target.value)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Project Details"
              type="text"
              autoComplete="current-password"
            />

            <TextField
              onChange={(event) => setLead(event.target.value)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Project Lead"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setEstimatedBudget(event.target.value)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="Estimated Budget"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setEmail(event.target.email)}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              label="In Charge Email"
              type="text"
              autoComplete="current-password"
            />
            <TextField
              onChange={(event) => setDoc(event.target.files[0])}
              style={{ margin: "30px" }}
              className="loginKeyArea"
              id="outlined-password-input"
              type="file"
              autoComplete="current-password"
            />

            <Button onClick={handleSubmit} id="lgnBtn" variant="contained">
              Apply
            </Button>
          </div>

          <div className="grantorLoginBox2" id="grantorReginBox2">
            <div className="imggHolder">
              <Image
                id="regImg"
                className="logo"
                src="Images/undraw_job_hunt_re_q203.svg"
                alt="logo0"
              />
              <br />
              <p id="regTxt">Say hello to a greater possibilities!</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default BeneficiaryFundApply;
