import React from 'react'
import BeneficiariesDashboard from '../BeneficiariesDashboard/BeneficiariesDashboard'
import './Applied.css';

function Applied() {
    return (
        <div>
            <BeneficiariesDashboard />
            <div className="appliedBox">
                <span className='appliedText'>Application sent for review!</span>
            </div>

        </div>
    )
}

export default Applied