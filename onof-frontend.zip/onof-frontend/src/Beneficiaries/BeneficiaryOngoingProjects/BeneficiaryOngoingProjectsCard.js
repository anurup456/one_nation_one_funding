import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import Button from '@mui/material/Button';
import './BeneficiaryOngoingProjectsCard.css';
import { useState, useEffect } from 'react';



function BeneficiaryOngoingProjectsCard() {


    const [users, setUsers] = useState([]);

    const getUsers = async () => {
        const response = await fetch('');
        setUsers(await response.json());
    }
    useEffect(() => {
        getUsers();
    }, []);

    return (
        <div>
            <div className="beneficiaryOngoingProjectsCardCon">
                <div className="beneficiaryOngoingProjectsCardBox">
                    <Card >
                        <CardActionArea>
                            <CardContent id='beneficiaryOngoingProjBtns' >
                                <Button id='beneficiaryOngoingProjBtn'>Scheme Id.</Button>
                                <Button id='beneficiaryOngoingProjBtn' >Scheme Title</Button>
                                <Button id='beneficiaryOngoingProjBtn' >Grantor</Button>
                                <Button id='beneficiaryOngoingProjBtn' >In Charge</Button>
                                <Button id='beneficiaryOngoingProjBtn' >Deadline</Button>

                            </CardContent>
                        </CardActionArea>
                    </Card>


                    {users.map(OngoingSchemes => {
                        return (
                            <Card >
                                <CardActionArea>
                                    <CardContent id='beneficiaryOngoingProjContentBtns' >
                                        <Button id='beneficiaryOngoingProjContentBtn'>{OngoingSchemes.Id}.</Button>
                                        <Button id='beneficiaryOngoingProjContentBtn' >{OngoingSchemes.Name}</Button>
                                        <Button id='beneficiaryOngoingProjConetntBtn' >{OngoingSchemes.Grantor}</Button>
                                        <Button id='beneficiaryOngoingProjContentBtn' >{OngoingSchemes.InCharge}</Button>
                                        <Button id='beneficiaryOngoingProjConetntBtn' >{OngoingSchemes.ProjectDeadline}</Button>

                                    </CardContent>
                                </CardActionArea>
                            </Card>
                        )
                    })}
                </div>
            </div>
        </div>
    )
}

export default BeneficiaryOngoingProjectsCard