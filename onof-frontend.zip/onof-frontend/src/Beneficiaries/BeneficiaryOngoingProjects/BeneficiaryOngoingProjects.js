import React from 'react'
import BeneficiariesDashboard from '../BeneficiariesDashboard/BeneficiariesDashboard'
import BeneficiaryOngoingProjectsCard from './BeneficiaryOngoingProjectsCard'
import './BeneficiaryOngoingProjects.css';
import Footer from '../../Components/Footer/Footer'


function BeneficiaryOngoingProjects() {
    return (
        <div>
            <BeneficiariesDashboard />
            <div className="beneficiaryOngoingProjectsContainer">
                <span className='topTextBeneficiarySide'>Ongoing Projects</span>
                <div className="beneficiaryOngoingProjectsCardBox">
                    <BeneficiaryOngoingProjectsCard />
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default BeneficiaryOngoingProjects