import React from "react";
import BeneficiariesDashboard from "../BeneficiariesDashboard/BeneficiariesDashboard";
import BeneficiariesSideSchemeDetailsTable from "./BeneficiariesSideSchemeDetailsTable";
import "./BeneficiariesSideSchemeDetails.css";
import Footer from "../../Components/Footer/Footer";

function BeneficiariesSideSchemeDetails() {
  return (
    <div>
      <BeneficiariesDashboard />

      <div className="beneficiariesSideSchemeDetailsContainer">
        <div className="beneficiariesSideSchemeDetailsBox">
          <BeneficiariesSideSchemeDetailsTable />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default BeneficiariesSideSchemeDetails;
