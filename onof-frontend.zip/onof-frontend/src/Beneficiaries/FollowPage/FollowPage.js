import React from "react";
import BeneficiariesDashboard from "../BeneficiariesDashboard/BeneficiariesDashboard";
import "./FollowPage.css";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea } from "@mui/material";
import { useState, useEffect } from "react";
import Footer from "../../Components/Footer/Footer";
import toast from "react-hot-toast";
function FollowPage() {
  const [users, setUsers] = useState([]);

  return (
    <div>
      <BeneficiariesDashboard />
      <div className="followPageBoxCon">
        <div className="followPageBox">
          <div className="followPageBoxTop">
            <Card sx={{ width: 345 }}>
              <CardActionArea>
                <CardContent className="followTop">
                  <Typography gutterBottom variant="h5" component="div">
                    Grantors List
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </div>

          <div className="followPageBoxTop">
            <Card className="followPageBox1">
              <CardActionArea>
                <CardContent className="followPageBoxTopText">
                  <Typography gutterBottom variant="h7" component="div">
                    Scheme ID
                  </Typography>
                  <Typography gutterBottom variant="h7" component="div">
                    Scheme
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    Grantor
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    Follow
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
            {/* {users.map((Follow) => {
              return ( */}
            <Card className="followPageBox2">
              <CardActionArea>
                <CardContent className="followPageBoxTopText2">
                  <Typography gutterBottom variant="h7" component="div">
                    6776
                  </Typography>
                  <Typography gutterBottom variant="h7" component="div">
                    Star Scheme
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    MHA
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    <Button
                      onClick={() => toast.success("Followed Successfully")}
                      variant="outlined"
                    >
                      Yes
                    </Button>
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
            {/* );
            })} */}
            <Card className="followPageBox2">
              <CardActionArea>
                <CardContent className="followPageBoxTopText2">
                  <Typography gutterBottom variant="h7" component="div">
                    6776
                  </Typography>
                  <Typography gutterBottom variant="h7" component="div">
                    Star Scheme
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    MHA
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    <Button
                      onClick={() => toast.success("Followed Successfully")}
                      variant="outlined"
                    >
                      Yes
                    </Button>
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>{" "}
            <Card className="followPageBox2">
              <CardActionArea>
                <CardContent className="followPageBoxTopText2">
                  <Typography gutterBottom variant="h7" component="div">
                    3245
                  </Typography>
                  <Typography gutterBottom variant="h7" component="div">
                    Space Scheme
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    MHA
                  </Typography>

                  <Typography gutterBottom variant="h7" component="div">
                    <Button
                      onClick={() => toast.success("Followed Successfully")}
                      variant="outlined"
                    >
                      Yes
                    </Button>
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default FollowPage;
