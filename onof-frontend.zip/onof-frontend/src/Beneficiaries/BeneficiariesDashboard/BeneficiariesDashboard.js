import React, { useContext, useState, useEffect } from "react";
import Bar from "../../Components/Navbar/Navbar";
import "./BeneficiariesDashboard.css";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import AppState from "../../Store/AppState";
import AuthContext from "../../Store/AuthContext";

function BeneficiariesDashboard() {
  let navigate = useNavigate();
  const authCtx = useContext(AuthContext);
  const [institute, setInstitute] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/institute/instituteDetails/" + authCtx.userId)
      .then((res) => {
        return res.json();
      })
      .then((data) => setInstitute(data));
  }, []);

  return (
    <div>
      <Bar />
      <div className="dashCon">
        <div className="dashConBox">
          {institute.name}
          <br />
          {institute.address}
        </div>
      </div>

      <div className="dashOptionsContainer">
        <div className="dashOptionsBox">
          <div className="dashOptionsBox1">
            <Button
              onClick={() => {
                navigate("/BeneficiariesSideSchemeList");
              }}
              id="dashBtn"
              variant="contained"
            >
              Available SCHEMES
            </Button>
            <Button
              onClick={() => {
                navigate("/BeneficiaryOngoingProjects");
              }}
              id="dashBtn"
              variant="contained"
            >
              ongoing projects
            </Button>
            <Button
              onClick={() => {
                navigate("/FollowPage");
              }}
              id="dashBtn"
              variant="contained"
            >
              Grantor List
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BeneficiariesDashboard;
