import React, { useState } from "react";

const AppState = React.createContext({
  applicationId: "",
  schemeId: "",
});

export const AppStateProvider = (props) => {
  const initialApplicationId = localStorage.getItem("applicationId");
  const initialSchemeId = localStorage.getItem("schemeId");
  const [applicationId, setApplicationId] = useState(initialApplicationId);
  const [schemeId, setSchemeId] = useState(initialSchemeId);

  const setAppId = (id) => {
    setApplicationId(id);
    localStorage.setItem("applicationId", id);
  };

  const setSchId = (id) => {
    setSchemeId(id);
    localStorage.setItem("schemeId", id);
  };

  const contextValue = {
    applicationId: applicationId,
    schemeId: schemeId,
    setApplicationId: setAppId,
    setSchemeId: setSchId,
  };

  return (
    <AppState.Provider value={contextValue}>{props.children}</AppState.Provider>
  );
};

export default AppState;
