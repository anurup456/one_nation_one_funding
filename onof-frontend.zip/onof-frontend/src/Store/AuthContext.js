import React, { useState } from "react";

const AuthContext = React.createContext({
  token: "",
  email: "",
  id: null,
  userId: null,
  isLoggedIn: false,
  login: (token) => {},
  logout: () => {},
});

export const AuthContextProvider = (props) => {
  const initialToken = localStorage.getItem("token");
  const initialId = localStorage.getItem("id");
  const initialEmail = localStorage.getItem("email");
  const initialUserId = localStorage.getItem("userId");
  const [token, setToken] = useState(initialToken);
  const [id, setId] = useState(initialId);
  const [userId, setUserId] = useState(initialUserId);
  const [email, setEmail] = useState(initialEmail);
  const userIsLoggedIn = token;

  const loginHandler = async (data) => {
    setId(data.id);
    setEmail(data.email);
    setToken(data.accessToken);
    setUserId(data.userId);
    console.log(data);
    localStorage.setItem("userId", data.userId);
    localStorage.setItem("id", data.id);
    localStorage.setItem("email", data.email);
    localStorage.setItem("token", data.accessToken);
  };

  const logoutHandler = async () => {
    setToken(null);
    setId(null);
    setEmail(null);
    setUserId(null);
    localStorage.removeItem("userId");
    localStorage.removeItem("token");
    localStorage.removeItem("id");
    localStorage.removeItem("email");
  };

  const contextValue = {
    token: token,
    isLoggedIn: userIsLoggedIn,
    id: id,
    userId: userId,
    email: email,
    login: loginHandler,
    logout: logoutHandler,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
