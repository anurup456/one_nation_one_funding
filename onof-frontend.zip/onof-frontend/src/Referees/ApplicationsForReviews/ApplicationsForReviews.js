import React from "react";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import Footer from "../../Components/Footer/Footer";
import ApplicationsForReviewsCard from "./ApplicationsForReviewsCard";
import "./ApplicationsForReviews.css";

function ApplicationsForReviews() {
  return (
    <div>
      <Bar />
      <HeroSection />
      <div className="appRevBox">
        <div className="appRev">
          <ApplicationsForReviewsCard />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default ApplicationsForReviews;
