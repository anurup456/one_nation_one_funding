import React, { useContext } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./ApplicationsForReviewsCard.css";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import toast from "react-hot-toast";
// import Fab from "@material-ui/core/Fab";
import AddIcon from "@mui/icons-material/Add";
import AuthContext from "../../Store/AuthContext";
import AppState from "../../Store/AppState";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function ApplicationsForReviewsCard() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const authCtx = useContext(AuthContext);
  const appState = useContext(AppState);
  let navigate = useNavigate();

  const [applications, setApplications] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/referee/allApplications/" + authCtx.userId)
      .then((res) => {
        return res.json();
      })
      .then((data) => setApplications(data));
  }, []);

  return (
    <div>
      <div className="appRevCardBoxCon">
        <div className="appRevCardBox">
          <Card>
            <CardActionArea>
              <CardContent className="appRevcard">
                <Button id="appRevBtn">Id</Button>
                <Button id="appRevBtn">Title</Button>
                <Button id="appRevBtn">Institute</Button>
                <Button id="appRevBtn">Organisation</Button>
                <Button id="appRevBtn">Review</Button>
              </CardContent>
            </CardActionArea>
          </Card>
          {applications.map((Rev) => {
            return (
              <Card>
                <CardActionArea>
                  <CardContent className="revCardcontent">
                    <Button className="revListBtn">{Rev.applicationId}</Button>
                    <Button
                      className="revListBtn"
                      onClick={() => {
                        appState.setApplicationId(Rev._id);
                        navigate("/ProjectDetails");
                      }}
                    >
                      {Rev.title}
                    </Button>
                    <Button className="revListBtn">{Rev.instituteName}</Button>
                    <Button className="revListBtn">{Rev.grantorName}</Button>
                    <Button
                      onClick={handleOpen}
                      className="refBtn"
                      variant="outlined"
                    >
                      send
                    </Button>
                    <Modal
                      open={open}
                      onClose={handleClose}
                      aria-labelledby="modal-modal-title"
                      aria-describedby="modal-modal-description"
                    >
                      <Box sx={style}>
                        <Typography
                          id="modal-modal-title"
                          variant="h6"
                          component="h2"
                        >
                          Upload Review
                        </Typography>
                        <Button
                          variant="contained"
                          component="label"
                          color="primary"
                        >
                          <AddIcon /> Upload a file
                          <input
                            type="file"
                            onChange={(event) => {
                              const formData = new FormData();
                              formData.append("file", event.target.files[0]);
                              fetch(
                                "http://localhost:8080/referee/uploadReview/" +
                                  authCtx.userId +
                                  "/" +
                                  Rev._id,
                                {
                                  method: "POST",
                                  body: formData,
                                }
                              )
                                .then(async (res) => {
                                  if (res.ok) {
                                    return res.json();
                                  } else {
                                    const data = await res.json();
                                    let errorMessage = data.message;
                                    if (
                                      data &&
                                      data.error &&
                                      data.error.message
                                    ) {
                                      errorMessage = data.error.message;
                                    }
                                    throw new Error(errorMessage);
                                  }
                                })
                                .then((data) => {
                                  toast.success("Review Uploaded");
                                })
                                .catch((err) => {
                                  toast.error(err.message);
                                });
                            }}
                            hidden
                          />
                        </Button>
                      </Box>
                    </Modal>
                  </CardContent>
                </CardActionArea>
              </Card>
            );
          })}{" "}
        </div>
      </div>
    </div>
  );
}

export default ApplicationsForReviewsCard;
