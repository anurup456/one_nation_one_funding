import React from "react";
import Footer from "../../Components/Footer/Footer";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import "./ViewReviews.css";
import ViewReviewsCard from "./ViewReviewsCard";

function ViewReviews() {
  return (
    <div>
      <Bar />
      <HeroSection />
      <div className="viewBoxContainer">
        <div className="viewBox">
          <ViewReviewsCard />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default ViewReviews;
