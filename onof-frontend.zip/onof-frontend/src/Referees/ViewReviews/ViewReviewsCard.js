import React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./ViewReviewsCard.css";

function ViewReviewsCard() {
  return (
    <div>
      <div className="viewspg">
        <div className="viewCardPageTop">View Reviews</div>

        <div className="viewReviewCards">
          <Button id="revName" variant="contained">
            Reviewer
          </Button>

          <Button id="revView" variant="contained">
            View Review
          </Button>
        </div>
      </div>
    </div>
  );
}

export default ViewReviewsCard;
