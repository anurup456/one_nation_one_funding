import React, { useContext } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import Button from "@mui/material/Button";
import { Navigate, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./AllRefereesCard.css";
import AuthContext from "../../Store/AuthContext";
import AppState from "../../Store/AppState";
import toast from "react-hot-toast";

function AllRefereesCard() {
  const [users, setUsers] = useState([]);
  const authCtx = useContext(AuthContext);
  const appState = useContext(AppState);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:8080/referee/all/" + authCtx.userId)
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        console.log(data);
        setUsers(data);
      });
  }, []);

  const handleAppoint = (id) => {
    fetch(
      "http://localhost:8080/grantor/addReferee/" + appState.applicationId,
      {
        method: "POST",
        body: JSON.stringify({
          referee: id,
        }),
        headers: {
          "Content-Type": "application/json",
        },
      }
    )
      .then((res) => {
        if (res.ok) {
          return res.json();
        } else {
          return res.json().then((data) => {
            let errorMessage = data.message;

            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
            }

            throw new Error(errorMessage);
          });
        }
      })

      .then((data) => {
        navigate("/GrantorCurrentSchemeApplications");
        toast.success(data.message);
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };

  return (
    <div className="refCardBoxCon">
      <div className="refCardBox">
        <Card>
          <CardActionArea>
            <CardContent className="beneciaryCard">
              <Button id="benefiaciaryBtn">Name</Button>
              <Button id="benefiaciaryBtn">Designation</Button>
              <Button id="benefiaciaryBtn">Affiliation</Button>
              <Button id="benefiaciaryBtn">Email</Button>
              <Button id="benefiaciaryBtn">Appoint</Button>
            </CardContent>
          </CardActionArea>
        </Card>

        {users.map((Ref) => {
          return (
            <Card>
              <CardActionArea>
                <CardContent className="refCardContent">
                  <Button className="refListBtn">{Ref.name}</Button>
                  <Button className="refListBtn"> {Ref.designation}</Button>

                  <Button className="refListBtn">{Ref.institute}</Button>
                  <Button className="refListBtn">{Ref.email}</Button>
                  <Button
                    className="refBtn"
                    variant="outlined"
                    onClick={() => handleAppoint(Ref._id)}
                  >
                    Appoint
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

export default AllRefereesCard;
