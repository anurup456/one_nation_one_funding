import React from "react";
import Bar from "../../Components/Navbar/Navbar";
import HeroSection from "../../Pages/Landing/HeroSection/HeroSection";
import AllRefereesCard from "./AllRefereesCard";
import "./AllReferees.css";
import Footer from "../../Components/Footer/Footer";

function AllReferees() {
  return (
    <div>
      <Bar />
      <HeroSection />
      <div className="allRefBox">
        <div className="allRef">
          <AllRefereesCard />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default AllReferees;
