import React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import "./ProjectDetailsTable.css";

function ProjectDetailsTable() {
  return (
    <div>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead className="tableProj">
            <TableRow>
              <TableCell className="projMainDetail">Description</TableCell>
              <TableCell className="projMainDetailContent" align="left">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Quaerat, corporis quae! Explicabo dolore quod libero nam, eos
                quos delectus impedit quisquam magnam, fugit laudantium,
                necessitatibus unde ducimus quibusdam ab modi?
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell className="projMainDetail">In Charge</TableCell>
              <TableCell className="projMainDetailContent" align="left">
                Calories
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell className="projMainDetail">Email Id</TableCell>
              <TableCell className="projMainDetailContent" align="left">
                Calories
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell className="projMainDetail">
                Application Letter
              </TableCell>
              <TableCell className="projMainDetailContent" align="left">
                Calories
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell className="projMainDetail">Estimated Budget</TableCell>
              <TableCell className="projMainDetailContent" align="left">
                Calories
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell className="projMainDetail">
                Bank Account Number
              </TableCell>
              <TableCell className="projMainDetailContent" align="left">
                Calories
              </TableCell>
            </TableRow>
          </TableHead>
        </Table>
      </TableContainer>
    </div>
  );
}

export default ProjectDetailsTable;
