import React, { useContext, useState } from "react";
import Footer from "../Components/Footer/Footer";
import Bar from "../Components/Navbar/Navbar";
// import AppState from "../Store/AppState";
import "./ProjectDetails.css";
import ProjectDetailsTable from "./ProjectDetailsTable";

function ProjectDetails() {
  //   const appState = useContext(AppState);
  //   const [application, setApplication] = useState(null);
  //   fetch("http://localhost:8080/application/details/" + appState.applicationId)
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((data) => setApplication(data));
  return (
    <div>
      <Bar />
      <div className="dashTopBox">
        <div className="dashTopInsttName">Project Name</div>
        <div className="dashTopInsttAdd">
          Instt., State, District, city - Pin Code
        </div>
      </div>
      <div className="projectDetailsTable">
        <div className="projectDetailsTableBox">
          <ProjectDetailsTable />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default ProjectDetails;
