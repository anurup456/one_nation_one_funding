import React from 'react'
import { CardOne, CardThree, CardTwo } from './ParticipantCardData'
import ParticipantCard from './ParticipantCard'
import './ParticipantCardDisplay.css'

function ParticipantCardDisplay() {
    return (
        <div className='cardDisplay'>

            <ParticipantCard {...CardOne} />
            <ParticipantCard {...CardTwo} />
            <ParticipantCard {...CardThree} />


        </div>
    )
}

export default ParticipantCardDisplay
