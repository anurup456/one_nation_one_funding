export const CardOne = {

    topL: 'Partha IIT',
    img: 'Images/Pho.png',
    alt: '#truth'
}


export const CardTwo = {

    topL: 'Partha IIT',
    img: 'Images/Pho.png',
    alt: '#peace'
}


export const CardThree = {

    topL: 'Partha IIT',
    img: 'Images/Pho.png',
    alt: '#unite'
}
