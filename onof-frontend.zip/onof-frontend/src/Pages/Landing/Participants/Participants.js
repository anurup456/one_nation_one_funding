import React from 'react'
import ParticipantCard from './ParticipantCard';
import './Participants.css';
import ParticipantCardDisplay from './ParticipantsCardDisplay';


function Participants() {
    return (
        <div className="participantsBox">
            <div className='participants'>
                Who do we work with?
            </div>

            <br />
            <div className="PartCards">

                <ParticipantCardDisplay />


            </div>


        </div>


    )
}

export default Participants