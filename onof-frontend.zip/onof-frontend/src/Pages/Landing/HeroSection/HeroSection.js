import React from "react";
import { Image } from "react-bootstrap";
import "./HeroSection.css";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";

function HeroSection() {
  return (
    <div className="hero">
      <div className="heroImg">
        <div className="imgHolder">
          <Image className="logo" src="Images/Logo.png" alt="logo0" />
        </div>
      </div>

      <div className="heroBtn">
        <Button variant="contained" style={{ backgroundColor: "coral" }}>
          IMPORTANT DATES{" "}
        </Button>
      </div>
    </div>
  );
}

export default HeroSection;
