import React from 'react'
import './Announcements.css'

function Announcements() {
    return (



        <div className='announcementsContainer'>
            <div className="announcementsHead">

                <div className="topline">
                    Announcements
                </div>

            </div>


        </div>

    )
}

export default Announcements