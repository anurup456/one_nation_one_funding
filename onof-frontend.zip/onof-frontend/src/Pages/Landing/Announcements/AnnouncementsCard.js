import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea, CardActions } from "@mui/material";
import { useState } from "react";
import "./AnnouncementsCard.css";

function AnnouncementsCard() {
  return (
    <div className="cardAnnounce">
      <Card className="cards">
        <CardActionArea>
          <CardContent className="announceCard">
            <Typography
              className="announceTop"
              component="div"
              variant="h5"
              fontSize={18}
              fontWeight={600}
            >
              <div className="announceTop">New schemes under ISRO and DRDO</div>
            </Typography>

            <Typography className="announceBody" variant="body" fontSize={15}>
              <div className="announceBody">
                DRDO and ISRO have come up with latest university related
                schemes.
              </div>

              <div className="line">
                <hr />
              </div>
            </Typography>
          </CardContent>
        </CardActionArea>
      </Card>
    </div>
  );
}

export default AnnouncementsCard;
