import React from 'react'
import Announcements from './Announcements'
import AnnouncementsCard from './AnnouncementsCard'
import './AnnouncementCardDisplay.css';

function AnnouncementCardDisplay() {
    return (
        <div className='announcementDisplay'>
            <Announcements />
            <AnnouncementsCard />
            <AnnouncementsCard />
            <AnnouncementsCard />

        </div>
    )
}

export default AnnouncementCardDisplay