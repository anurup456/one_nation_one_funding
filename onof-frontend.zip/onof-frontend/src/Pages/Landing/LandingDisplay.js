import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Bar from '../../Components/Navbar/Navbar';
import HeroSection from './HeroSection/HeroSection';
import AnnouncementCardDisplay from './Announcements/AnnouncementCardDisplay';
import ParticipantCard from './Participants/ParticipantCard';
import LandEnd from './LandEnd';
import Footer from '../../Components/Footer/Footer';

function LandingDisplay() {
    return (
        <div>
            <Bar />
            <HeroSection />
            <AnnouncementCardDisplay />
            <ParticipantCard />
            <LandEnd />
            <Footer />
        </div>
    )
}

export default LandingDisplay