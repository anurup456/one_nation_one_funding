import React from 'react'
import Footer from '../../Components/Footer/Footer'
import Bar from '../../Components/Navbar/Navbar'
import './Contact.css'

function Contact() {
    return (
        <div>
            <Bar />


            <div className="contact_form">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-10 offset-lg-1">
                            <div className="contact_form_title">
                                <div id='contactTitle'>Reach Out</div></div>
                            <form id="contact_form">

                                <div className="contact_form_top_bar">
                                    <input type="text" class="form-control" id="#" placeholder="Name"></input>
                                    <input type="text" class="form-control" id="#" placeholder="Email"></input>
                                    <input type="text" class="form-control" id="#" placeholder="Phone Number"></input>
                                </div>

                                <div className="contact_form_text mt-4">
                                    <textarea className="text_field" placeholder='Message' cols="30" rows="10">

                                    </textarea>


                                </div>

                                <div className='contact_form_button'>
                                    <button type="submit" className="btn-warning">Send Message</button>

                                </div>

                            </form>


                        </div>

                    </div>

                </div>
                <div className="footC">  <Footer /></div>
            </div>




        </div >
    )
}

export default Contact