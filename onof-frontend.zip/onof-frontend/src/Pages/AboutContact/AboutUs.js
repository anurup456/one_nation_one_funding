import React from 'react'
import Footer from '../../Components/Footer/Footer'
import Bar from '../../Components/Navbar/Navbar'
import './AboutUs.css'

function AboutUs() {
    return (
        <div>
            <Bar />
            <div className="aboutContainer">
                <div className="aboutBox">
                    <div className="aboutLogo"></div>
                    <div className="aboutText">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aperiam aliquid quod eius quae reprehenderit ut reiciendis veniam neque dicta deleniti amet dignissimos ex deserunt, quam vero dolore nobis possimus odio quisquam iure minus? Exercitationem facilis quo tenetur! Perspiciatis, reiciendis est!</div>
                </div>
            </div>
            <div className="footerA">
                <Footer />
            </div>

        </div>
    )
}

export default AboutUs