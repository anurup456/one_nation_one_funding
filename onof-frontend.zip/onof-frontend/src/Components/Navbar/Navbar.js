import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import "./Navbar.css";
import { useNavigate } from "react-router-dom";
import AuthContext from "../../Store/AuthContext";
import toast from "react-hot-toast";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "white",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function Bar() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const authCtx = React.useContext(AuthContext);

  let navigate = useNavigate();

  return (
    <Navbar id="navBox" bg="light" expand="lg">
      <Container>
        <Navbar.Brand id="navText" href="#home">
          FundVerse
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          {!authCtx.isLoggedIn && (
            <Nav className="me-auto">
              <Nav.Link
                style={{ color: " #1D4F8E" }}
                onClick={() => {
                  navigate("/");
                }}
              >
                Home
              </Nav.Link>

              <NavDropdown title="Register" id="basic-nav-dropdown">
                <NavDropdown.Item
                  onClick={() => {
                    navigate("/GrantorRegister");
                  }}
                >
                  Grantor Registration
                </NavDropdown.Item>

                <NavDropdown.Item
                  onClick={() => {
                    navigate("/BeneficiaryRegister");
                  }}
                >
                  Institute Registration
                </NavDropdown.Item>
              </NavDropdown>

              <NavDropdown title="Login" id="basic-nav-dropdown">
                <NavDropdown.Item onClick={handleOpen}>
                  Grantor Login
                </NavDropdown.Item>

                <Modal
                  open={open}
                  onClose={handleClose}
                  aria-labelledby="modal-modal-title"
                  aria-describedby="modal-modal-description"
                >
                  <Box sx={style}>
                    <Typography
                      id="modal-modal-title"
                      variant="h6"
                      component="h2"
                    >
                      Choose Role
                    </Typography>
                    <div className="modBtn">
                      <Button
                        id="btnMod"
                        onClick={() => {
                          navigate("/GrantorLogin");
                        }}
                        variant="contained"
                      >
                        Grantor Login
                      </Button>
                      <Button
                        id="btnMod"
                        onClick={() => {
                          navigate("/RefereeLogin");
                        }}
                        variant="contained"
                      >
                        Referee login
                      </Button>
                    </div>
                  </Box>
                </Modal>

                <NavDropdown.Item
                  onClick={() => {
                    navigate("/BeneficiaryLogin");
                  }}
                >
                  Institute Login
                </NavDropdown.Item>
              </NavDropdown>

              <Nav.Link
                onClick={() => {
                  navigate("/AboutUs");
                }}
                style={{ color: " #1D4F8E" }}
              >
                About{" "}
              </Nav.Link>
              <Nav.Link
                onClick={() => {
                  navigate("/Contact");
                }}
                style={{ color: " #1D4F8E" }}
              >
                Contact
              </Nav.Link>
            </Nav>
          )}
          {authCtx.isLoggedIn && (
            <Nav className="me-auto">
              <Nav.Link
                style={{ color: " #1D4F8E" }}
                onClick={() => {
                  authCtx.logout();
                  navigate("/");
                  toast.success("Logged Out Successfully");
                }}
              >
                Logout
              </Nav.Link>
            </Nav>
          )}
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Bar;
