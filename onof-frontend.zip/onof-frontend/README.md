sih one
npm i react-router-dom
npm build
npm i --save bootstrap

npm i @mui/icons-material


Issues:
Contact Us white space at bottom
search bar in lists



GRANTOR SIDE INFO:

login -> projects under our schemes

open scheme btn -> applicant no -> shows applications with accept and reject

scheme details can be viewed by pressing on schemes in open and active scheme list

///////////////////
fa side

grantor side open schemes ...when we click on the number of applicants then we get current applications list and there the fa can see if any reviews were given and also has accept and the reject button .. here on clicking the review side fa will be taken to the page that has all the reviews of this articular projecty


































