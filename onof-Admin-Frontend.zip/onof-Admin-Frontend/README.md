npm i react-modal
https://jsonplaceholder.typicode.com/photos

sample database here

sample.json files are given only for tests can be deleted

npm install react react-dom --save

npm install react-router-dom@6



ISSUES
-grantor requests
-rendering letter
-colour scheme


SAMYA's CHANGES
-in ApprovedBeneficiaryCard.js, updated list of approved beneficiary, added instt code, name of Head, and removed area of expertise
-in BeneficiaryRequestCard.js, updated list of approved beneficiary, added instt code, name of Head, and removed area of expertise
-in both of the above, the parameter names are BeneficiaryCode, BeneficiaryHead