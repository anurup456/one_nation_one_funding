import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import "./Navbar.css";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import { useContext } from "react";
import AuthContext from "../Store/AuthContext";

function Bar() {
  let navigate = useNavigate();
  const authCtx = useContext(AuthContext);

  return (
    <Navbar id="navBox" bg="light" expand="lg">
      <Container style={{ display: "flex", justifyContent: "space-between" }}>
        <Navbar.Brand id="navText" href="#home">
          One Nation-One Funding
        </Navbar.Brand>
        {/* <Navbar.Toggle aria-controls="basic-navbar-nav" /> */}

        <Nav>
          {authCtx.isLoggedIn && (
            <Button
              style={{ backgroundColor: " #1D4F8E" }}
              variant="contained"
              onClick={authCtx.logout}
            >
              Logout
            </Button>
          )}
        </Nav>
      </Container>
    </Navbar>
  );
}

export default Bar;
