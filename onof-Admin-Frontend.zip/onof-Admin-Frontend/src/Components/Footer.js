import React from "react";
import "./Footer.css";

function Footer() {
  return <div className="foot">Copyright &copy; 2022 FundVerse</div>;
}

export default Footer;
