import "./App.css";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import GrantorRequest from "./Pages/GrantorRequests/GrantorRequest";
import AdminChooseDisplay from "./Pages/AdminChoose/AdminChooseDisplay";
import ApprovedBeneficiaries from "./Pages/ApprovedBeneficiary/ApprovedBeneficiaries";
import ApprovedGrantors from "./Pages/ApprovedGrantors/ApprovedGrantors";
import BeneficiaryRequest from "./Pages/BeneficiaryRequests/BeneficiaryRequest";
import AdminLogin from "./Pages/Login/AdminLogin";
import { Toaster } from "react-hot-toast";
import { useContext } from "react";
import AuthContext from "./Store/AuthContext";

import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  const authCtx = useContext(AuthContext);
  return (
    <div className="App">
      {authCtx.isLoggedIn && (
        <Routes>
          <Route path="/Choose" element={<AdminChooseDisplay />} />

          <Route path="/GrantorRequest" element={<GrantorRequest />} />

          <Route path="/BeneficiaryRequest" element={<BeneficiaryRequest />} />
          <Route
            path="/ApprovedBeneficiaries"
            element={<ApprovedBeneficiaries />}
          />
          <Route path="/ApprovedGrantors" element={<ApprovedGrantors />} />
          <Route path="*" element={<AdminChooseDisplay />}></Route>
        </Routes>
      )}
      {!authCtx.isLoggedIn && (
        <Routes>
          <Route path="/" element={<AdminLogin />} exact />
          <Route path="*" element={<AdminLogin />}></Route>
        </Routes>
      )}

      <Toaster position="top-center" />
    </div>
  );
}

export default App;
