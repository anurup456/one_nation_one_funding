import React, { useState } from "react";
import toast from "react-hot-toast";
const AuthContext = React.createContext({
  token: "",
  isLoggedIn: false,
  login: (token) => {},
  logout: () => {},
});

export const AuthContextProvider = (props) => {
  const initialToken = localStorage.getItem("token");

  const [token, setToken] = useState(initialToken);

  const userIsLoggedIn = token ? true : false;

  const loginHandler = async (data) => {
    setToken(data.accessToken);
    localStorage.setItem("token", data.accessToken);
  };

  const logoutHandler = async () => {
    setToken(null);

    localStorage.removeItem("token");
    toast.success("Signed Out Successfully")
  };

  const contextValue = {
    token: token,
    isLoggedIn: userIsLoggedIn,

    login: loginHandler,
    logout: logoutHandler,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
