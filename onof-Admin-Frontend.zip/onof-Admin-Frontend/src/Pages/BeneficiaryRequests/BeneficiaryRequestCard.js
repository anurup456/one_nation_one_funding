import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea, CardActions } from "@mui/material";
import Data from "./SampleData.json";
import "./BeneficiaryRequestCard.css";
import { useState } from "react";
import toast from "react-hot-toast";

import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { useEffect } from "react";

function BeneficiaryrequestCard({ Beneficiary, setUsers }) {
  const [show, setShow] = useState(false);

  const openDoc = async (id) => {
    await fetch("http://localhost:8080/admin/instituteDocs/" + id)
      .then((res) => {
        return res.blob();
      })
      .then((blob) => {
        const file = new Blob([blob], { type: "application/pdf" });
        const fileURL = URL.createObjectURL(file);
        const pdfWindow = window.open();
        pdfWindow.location.href = fileURL;
      });
  };

  const acceptBeneficiary = async (id) => {
    await fetch("http://localhost:8080/admin/verifyInstitute/" + id, {
      method: "POST",
    })
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        toast.success(res.message);
        setUsers(null);
      })
      .catch((err) => {
        toast.error(err);
      });
  };

  const rejectBeneficiary = async (id) => {
    await fetch("http://localhost:8080/admin/rejectInstitute/" + id, {
      method: "POST",
    })
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        toast.success(res.message);
        setUsers(null);
      })
      .catch((err) => {
        toast.error(err);
      });
  };

  return (
    <div className="grantorRequestCards">
      <Card id="reqCard" sx={{ maxWidth: 745 }}>
        <CardActionArea>
          <CardContent className="contentCard">
            <Typography
              className="instName"
              gutterBottom
              variant="h5"
              component="div"
            >
              {Beneficiary.name}
            </Typography>
            <Typography
              className="instAdd"
              variant="body2"
              color="text.secondary"
            >
              {Beneficiary.address}
            </Typography>
          </CardContent>
        </CardActionArea>

        <CardActions className="cardActionBox">
          {show && (
            <div className="hide">
              <TableContainer id="detailsTable" component={Paper}>
                <Table sx={{ maxWidth: 750 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell>INSTITUTE NAME</TableCell>
                      <TableCell align="right">{Beneficiary.name}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>INSTITUTE CODE</TableCell>
                      <TableCell align="right">{Beneficiary.code}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>HEAD OF INSTITUTE</TableCell>
                      <TableCell align="right">{Beneficiary.head}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>INSTITUTE ADDRESS</TableCell>
                      <TableCell align="right">{Beneficiary.address}</TableCell>
                    </TableRow>

                    {/* <TableRow>
                          <TableCell>AREA OF EXPERTISE</TableCell>
                          <TableCell align="right">
                            {Beneficiary.BeneficiaryExpertise}
                          </TableCell>
                        </TableRow> */}

                    <TableRow>
                      <TableCell>POINT OF CONTACT</TableCell>
                      <TableCell align="right">{Beneficiary.poc}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>EMAIL</TableCell>
                      <TableCell align="right">{Beneficiary.email}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>PROPOSAL LETTER</TableCell>
                      <TableCell
                        id="hoverr"
                        style={{ color: "blue" }}
                        onClick={() => {
                          openDoc(Beneficiary._id);
                        }}
                        align="right"
                      >
                        {Beneficiary.document}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody></TableBody>
                </Table>
              </TableContainer>
            </div>
          )}

          <span>
            {show && (
              <Button
                onClick={() => acceptBeneficiary(Beneficiary._id)}
                id="view"
                size="small"
                color="primary"
                variant="contained"
              >
                Accept
              </Button>
            )}
            {show && (
              <Button
                onClick={() => rejectBeneficiary(Beneficiary._id)}
                id="view"
                size="small"
                color="primary"
                variant="contained"
              >
                Reject
              </Button>
            )}
          </span>
          <Button
            onClick={() => setShow(!show)}
            id="view"
            size="small"
            color="primary"
            variant="contained"
          >
            {show == true ? "hide details" : "show details"}
          </Button>
        </CardActions>
      </Card>
    </div>
  );
}

export default BeneficiaryrequestCard;
