import React, { useState, useEffect } from "react";
import { Image } from "react-bootstrap";
import "./GrantorRequest.css";
import GrantorRequestCard from "./GrantorRequestCard";
import Header from "../../Components/Navbar";
import Footer from "../../Components/Footer";

function GrantorRequest() {
  const [users, setUsers] = useState([]);

  const getUsers = async () => {
    await fetch("http://localhost:8080/admin/grantor/proposals")
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        setUsers(res);
      });
  };

  useEffect(() => {
    getUsers();
  }, [users]);

  return (
    <div>
      <Header />
      <div className="heroImg">
        <div className="imgHolder">
          <Image className="logo" src="Images/Logo.png" alt="logo0" />
        </div>
      </div>

      <div className="texts">GRANTOR REQUESTS</div>

      <div className="requestList">
        {users.length === 0 && <>No Pending Requests</>}
        {users.length !== 0 &&
          users.map((user) => {
            return <GrantorRequestCard Grantor={user} setUsers={setUsers} />;
          })}
      </div>

      <Footer />
    </div>
  );
}

export default GrantorRequest;
