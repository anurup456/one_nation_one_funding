import React, { useEffect } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea, CardActions } from "@mui/material";
import "./GrantorRequestCard.css";
import { useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import toast from "react-hot-toast";

function GrantorRequestCard({ Grantor, setUsers }) {
  const [show, setShow] = useState(false);

  const openDoc = async (id) => {
    await fetch("http://localhost:8080/admin/grantorDocs/" + id)
      .then((res) => {
        return res.blob();
      })
      .then((blob) => {
        const file = new Blob([blob], { type: "application/pdf" });
        const fileURL = URL.createObjectURL(file);
        const pdfWindow = window.open();
        pdfWindow.location.href = fileURL;
      });
  };

  const acceptGrantor = async (id) => {
    await fetch("http://localhost:8080/admin/verifyGrantor/" + id, {
      method: "POST",
    })
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        setUsers(null);
        toast.success(res.message);
      })
      .catch((err) => {
        toast.error(err);
      });
  };

  const rejectGrantor = async (id) => {
    await fetch("http://localhost:8080/admin/rejectGrantor/" + id, {
      method: "POST",
    })
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        setUsers(null);
        toast.success(res.message);
      })
      .catch((err) => {
        toast.error(err);
      });
  };

  return (
    <div className="grantorRequestCards">
      <Card id="reqCard" sx={{ maxWidth: 745 }}>
        <CardActionArea>
          <CardContent className="contentCard">
            <Typography
              className="instName"
              gutterBottom
              variant="h5"
              component="div"
            >
              {Grantor.name}
            </Typography>
            <Typography
              className="instAdd"
              variant="body2"
              color="text.secondary"
            >
              {Grantor.address}
            </Typography>
          </CardContent>
        </CardActionArea>

        <CardActions className="cardActionBox">
          {show && (
            <div className="hide">
              <TableContainer id="detailsTable" component={Paper}>
                <Table sx={{ maxWidth: 750 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell>GRANTOR NAME</TableCell>
                      <TableCell align="right">{Grantor.name}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>ADDRESS OF OPERATION</TableCell>
                      <TableCell align="right">{Grantor.address}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>AREA OF RESEARCH</TableCell>
                      <TableCell align="right">
                        {Grantor.researchArea}
                      </TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>HEAD OF ORG.</TableCell>
                      <TableCell align="right">{Grantor.head}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>EMAIL</TableCell>
                      <TableCell align="right">{Grantor.email}</TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>PROPOSAL LETTER</TableCell>
                      <TableCell
                        id="hoverr"
                        style={{ color: "blue" }}
                        onClick={() => openDoc(Grantor._id)}
                        align="right"
                      >
                        {Grantor.document}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody></TableBody>
                </Table>
              </TableContainer>
            </div>
          )}

          <span>
            {show && (
              <Button
                onClick={() => acceptGrantor(Grantor._id)}
                id="view"
                size="small"
                color="primary"
                variant="contained"
              >
                Accept
              </Button>
            )}
            {show && (
              <Button
                onClick={() => rejectGrantor(Grantor._id)}
                id="view"
                size="small"
                color="primary"
                variant="contained"
              >
                Reject
              </Button>
            )}
          </span>
          <Button
            onClick={() => setShow(!show)}
            id="view"
            size="small"
            color="primary"
            variant="contained"
          >
            {show == true ? "hide details" : "show details"}
          </Button>
        </CardActions>
      </Card>
    </div>
  );
}

export default GrantorRequestCard;
