import React from "react";
import Footer from "../../Components/Footer";
import Header from "../../Components/Navbar";
import AdminChoose from "./AdminChoose";
import {Image} from 'react-bootstrap'

function AdminChooseDisplay() {
  return (
    <div>
      <Header />
     
      <div className="heroImg">
        <div className="imgHolder">
          <Image className="logo" src="Images/Logo.png" alt="logo0" />
        </div>
      </div>
      <AdminChoose />
      <div className="footerAdmin">
        <Footer />
      </div>
    </div>
  );
}

export default AdminChooseDisplay;
