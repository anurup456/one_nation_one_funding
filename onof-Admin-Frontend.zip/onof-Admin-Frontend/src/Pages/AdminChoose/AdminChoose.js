import React from "react";
import "./AdminChoose.css";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";

function AdminChoose() {
  let navigate = useNavigate();

  return (
    <div className="adminSelect">
      <span id="wel">Welcome Admin</span>
      <div className="adminSelectBox">
        <div className="adminSelectBox1">
          <Button
            onClick={() => {
              navigate("/GrantorRequest");
            }}
            id="adminBtn"
            className="adminButton"
            variant="contained"
          >
            Grantor Request
          </Button>

          <Button
            onClick={() => {
              navigate("/BeneficiaryRequest");
            }}
            id="adminBtn"
            className="adminButton"
            variant="contained"
          >
            Institute request
          </Button>
        </div>

        <div className="adminSelectBox2">
          <Button
            onClick={() => {
              navigate("/ApprovedGrantors");
            }}
            id="adminBtn"
            className="adminButton"
            variant="contained"
          >
            Approved grantors
          </Button>

          <Button
            onClick={() => {
              navigate("/ApprovedBeneficiaries");
            }}
            id="adminBtn"
            className="adminButton"
            variant="contained"
          >
            Approved Institutes
          </Button>
        </div>
      </div>
    </div>
  );
}

export default AdminChoose;
