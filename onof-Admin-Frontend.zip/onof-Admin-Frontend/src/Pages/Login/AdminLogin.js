import React from "react";
import Header from "../../Components/Navbar";
import "./AdminLogin.css";
import Button from "@mui/material/Button";
import Footer from "../../Components/Footer";
import toast from "react-hot-toast";
import { useContext, useState } from "react";
import AuthContext from "../../Store/AuthContext";
import { Image } from "react-bootstrap";

const AdminLogin = () => {
  const authCtx = useContext(AuthContext);
  const [pass, setPass] = useState("");

  const handleLoginSubmit = (event) => {
    event.preventDefault();
    fetch("http://localhost:8080/api/admin/signin/", {
      method: "POST",
      body: JSON.stringify({
        password: pass,
        returnSecureToken: true,
      }),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((res) => {
        if (res.ok) {
          return res.json();
        } else {
          return res.json().then((data) => {
            let errorMessage = data.message;

            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
            }

            throw new Error(errorMessage);
          });
        }
      })
      .then((data) => {
        toast.success("Signed In Successfully");
        authCtx.login(data);
      })
      .catch((err) => {
        toast.error(err.message);
      });
  };

  return (
    <div className="loginPage">
      <Header />

      <div className="loginPageBody">
        <div className="heroImg">
          <div className="imgHolder">
            <Image className="logo" src="Images/Logo.png" alt="logo0" />
          </div>
        </div>

        <div className="loginBoxContainer">
          <div className="loginBox1">
            <h1 id="adminLog">ADMIN LOGIN</h1>

            <form className="loginForm">
              <label>
                <input
                  id="loginKeyArea"
                  type="text"
                  name="name"
                  placeholder=" Enter Key"
                  onChange={(event) => setPass(event.target.value)}
                />
              </label>

              <input
                onClick={handleLoginSubmit}
                id="submitBtn"
                className="adminButton"
                type="submit"
              />
            </form>
          </div>

          <div className="loginBox2">
            <Image
              className="logoAd"
              src="Images/undraw_businessman_re_mlee.svg"
              alt="logo0"
            />
          </div>
        </div>
      </div>
      <div className="loginBottom">
        <Footer />
      </div>
    </div>
  );
};

export default AdminLogin;
