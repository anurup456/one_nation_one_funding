import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea, CardActions, Link } from "@mui/material";
import Data from "./SampleData.json";
import "./ApprovedBeneficiariesCard.css";
import { useState, useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

function ApprovedBeneficiariesCard({ ApprovedBeneficiary }) {
  const [show, setShow] = useState(false);
  const openDoc = async (id) => {
    await fetch("http://localhost:8080/admin/instituteDocs/" + id)
      .then((res) => {
        return res.blob();
      })
      .then((blob) => {
        const file = new Blob([blob], { type: "application/pdf" });
        const fileURL = URL.createObjectURL(file);
        const pdfWindow = window.open();
        pdfWindow.location.href = fileURL;
      });
  };

  return (
    <div className="cards">
      <Card id="reqCard" sx={{ maxWidth: 745 }}>
        <CardActionArea>
          <CardContent className="contentCard">
            <Typography
              className="instName"
              gutterBottom
              variant="h5"
              component="div"
            >
              {ApprovedBeneficiary.name}
            </Typography>
            <Typography
              className="instAdd"
              variant="body2"
              color="text.secondary"
            >
              {ApprovedBeneficiary.address}
            </Typography>
          </CardContent>
        </CardActionArea>

        <CardActions className="cardActionBox">
          {show && (
            <div className="hide">
              <TableContainer id="detailsTable" component={Paper}>
                <Table sx={{ maxWidth: 750 }} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell>INSTITUTE NAME</TableCell>
                      <TableCell align="right">
                        {ApprovedBeneficiary.name}
                      </TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>INSTITUTE CODE</TableCell>
                      <TableCell align="right">
                        {ApprovedBeneficiary.code}
                      </TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>HEAD OF INSTITUTE</TableCell>
                      <TableCell align="right">
                        {ApprovedBeneficiary.head}
                      </TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>INSTITUTE ADDRESS</TableCell>
                      <TableCell align="right">
                        {ApprovedBeneficiary.address}
                      </TableCell>
                    </TableRow>

                    {/* <TableRow>
                          <TableCell>AREA OF EXPERTISE</TableCell>
                          <TableCell align="right">
                            {ApprovedBeneficiary.ApprovedBeneficiaryExpertise}
                          </TableCell>
                        </TableRow> */}

                    <TableRow>
                      <TableCell>POINT OF CONTACT</TableCell>
                      <TableCell align="right">
                        {ApprovedBeneficiary.poc}
                      </TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>EMAIL</TableCell>
                      <TableCell align="right">
                        {ApprovedBeneficiary.email}
                      </TableCell>
                    </TableRow>

                    <TableRow>
                      <TableCell>PROPOSAL LETTER</TableCell>
                      <TableCell
                        id="hoverr"
                        style={{ color: "blue" }}
                        onClick={() => openDoc(ApprovedBeneficiary._id)}
                      >
                        {ApprovedBeneficiary.document}
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody></TableBody>
                </Table>
              </TableContainer>
            </div>
          )}

          <Button
            onClick={() => setShow(!show)}
            id="view"
            size="small"
            color="primary"
            variant="contained"
          >
            {show == true ? "hide details" : "show details"}
          </Button>
        </CardActions>
      </Card>
    </div>
  );
}

export default ApprovedBeneficiariesCard;
