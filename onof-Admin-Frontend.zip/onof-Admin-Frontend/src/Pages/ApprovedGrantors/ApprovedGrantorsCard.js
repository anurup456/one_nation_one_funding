import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Button, CardActionArea, CardActions, Link } from "@mui/material";
import Data from "./SampleData.json";
import "./ApprovedGrantorsCard.css";
import { useState, useEffect } from "react";

import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

function ApprovedGrantorsCard({ ApprovedGrantor }) {
  const [show, setShow] = useState(false);

  const openDoc = async (id) => {
    await fetch("http://localhost:8080/admin/grantorDocs/" + id)
      .then((res) => {
        return res.blob();
      })
      .then((blob) => {
        const file = new Blob([blob], { type: "application/pdf" });
        const fileURL = URL.createObjectURL(file);
        const pdfWindow = window.open();
        pdfWindow.location.href = fileURL;
      });
  };

  return (
    <Card id="reqCard" sx={{ maxWidth: 745 }}>
      <CardActionArea>
        <CardContent className="contentCard">
          <Typography
            className="instName"
            gutterBottom
            variant="h5"
            component="div"
          >
            {ApprovedGrantor.name}
          </Typography>
          <Typography
            className="instAdd"
            variant="body2"
            color="text.secondary"
          >
            {ApprovedGrantor.address}
          </Typography>
        </CardContent>
      </CardActionArea>

      <CardActions className="cardActionBox">
        {show && (
          <div className="hide">
            <TableContainer id="detailsTable" component={Paper}>
              <Table sx={{ maxWidth: 750 }} aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>ORGANISATION NAME</TableCell>
                    <TableCell align="right">{ApprovedGrantor.name}</TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell>ADDRESS OF OPERATION</TableCell>
                    <TableCell align="right">
                      {ApprovedGrantor.address}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>AREA OF RESEARCH</TableCell>
                    <TableCell align="right">
                      {ApprovedGrantor.researchArea}
                    </TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell>HEAD OF ORG.</TableCell>
                    <TableCell align="right">{ApprovedGrantor.head}</TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell>EMAIL</TableCell>
                    <TableCell align="right">{ApprovedGrantor.email}</TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell>PROPOSAL LETTER</TableCell>
                    <TableCell
                      id="hoverr"
                      style={{ color: "blue" }}
                      onClick={() => openDoc(ApprovedGrantor._id)}
                      align="right"
                    >
                      {ApprovedGrantor.document}
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody></TableBody>
              </Table>
            </TableContainer>
          </div>
        )}

        <Button
          onClick={() => setShow(!show)}
          id="view"
          size="small"
          color="primary"
          variant="contained"
        >
          {show == true ? "hide details" : "show details"}
        </Button>
      </CardActions>
    </Card>
  );
}

export default ApprovedGrantorsCard;
