import React, { useState, useEffect } from "react";
import { Image } from "react-bootstrap";
import Header from "../../Components/Navbar";
import Footer from "../../Components/Footer";
import ApprovedGrantorsCard from "./ApprovedGrantorsCard";
import "./ApprovedGrantors.css";


function ApprovedGrantors() {
  const [users, setUsers] = useState([]);

  const getUsers = async () => {
    await fetch("http://localhost:8080/admin/grantor/approved")
      .then((res) => {
        return res.json();
      })
      .then((res) => {
        console.log(res);
        setUsers(res);
      });
  };

  useEffect(() => {
    getUsers();
  }, []);
  return (
    <div>
      <Header />
      <div className="heroImg">
        <div className="imgHolder">
          <Image className="logo" src="Images/Logo.png" alt="logo0" />
        </div>
      </div>

      <div className="texts">LIST OF APPROVED GRANTORS</div>

      <div className="requestList">
        <div className="cards">
          {users.length === 0 && <>No Approved Grantors</>}
          {users.map((user) => {
            return <ApprovedGrantorsCard ApprovedGrantor={user} />;
          })}
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default ApprovedGrantors;
