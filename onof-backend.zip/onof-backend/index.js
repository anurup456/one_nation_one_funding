const express = require("express");
const mongoose = require("mongoose");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
require("dotenv").config();
const connection = require("./db");
const fs = require("fs");
const grantorRoutes = require("./routes/grantor");
const instituteRoutes = require("./routes/institute");
const adminRoutes = require("./routes/admin");
const schemeRoutes = require("./routes/scheme");
const applicationRoutes = require("./routes/application");
const threadRoutes = require("./routes/thread");
const refereeRoutes = require("./routes/referee");

connection();
var corsOptions = {
  origin: ["http://localhost:3000", "http://localhost:3001S"],
};
// app.use(express.bodyParser({ limit: "50mb" }));
app.use(cors(corsOptions));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/grantor", grantorRoutes);
app.use("/institute", instituteRoutes);

require("./routes/admin_auth.routes")(app);

app.use("/admin", adminRoutes);
app.use("/scheme", schemeRoutes);
app.use("/application", applicationRoutes);
app.use("/thread", threadRoutes);
app.use("/referee", refereeRoutes);

app.listen(8080, () => {
  console.log("Server up at 8080");
});
