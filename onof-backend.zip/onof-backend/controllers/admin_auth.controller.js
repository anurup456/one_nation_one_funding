const config = require("../config/auth.config");
require("dotenv").config();

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.signin = (req, res) => {
  if (req.body.password === process.env.ADMIN_KEY) {
    var token = jwt.sign({ id: "ADMIN" }, config.secret, {
      expiresIn: 86400,
    });

    res.status(200).send({
      msg: "Successfully logged in",
      accessToken: token,
    });
  } else {
    return res.status(401).send({
      accessToken: null,
      message: "Invalid Password! Please try again.",
    });
  }
};
