const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const schemeSchema = new Schema({
  psID: String,
  name: String,
  grantorName: String,
  grantorId: mongoose.Schema.Types.ObjectId,
  description: String,
  eligibility: [{ type: String }],
  tags: [{ type: String }],
  applicationDeadline: Date,
  fundingLimit: String,
  document: String,
  available: Boolean,
  postedApplications: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Application" },
  ],
  ongoingApplications: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Application" },
  ],
  pastApplications: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Application" },
  ],
});

const Scheme = mongoose.model("Scheme", schemeSchema);
module.exports = Scheme;
