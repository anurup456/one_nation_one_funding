const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const jwt = require("jsonwebtoken");
const refereeSchema = new Schema({
  name: String,
  refereeId: String,
  designation: String,
  institute: String,
  email: String,
  password: String,
  approved: Boolean,
  applications: [{ type: mongoose.Schema.Types.ObjectId, ref: "Application" }],
  projects: [{ type: mongoose.Schema.Types.ObjectId, ref: "Application" }],
});

refereeSchema.methods.generateAuthToken = () => {
  const token = jwt.sign({ _id: this.id }, process.env.JWTPRIVATEKEY, {
    expiresIn: "30d",
  });
  return token;
};

module.exports = mongoose.model("Referee", refereeSchema);
