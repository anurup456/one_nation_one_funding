const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const { Institute } = require("./institute");

const grantorSchema = new mongoose.Schema({
  name: String,
  head: String,
  researchArea: String,
  address: String,
  email: String,
  password: String,
  emailVerified: Boolean,
  approved: Boolean,
  document: String,
  proposed: Boolean,
  nextId: Number,
  referees: [{ type: mongoose.Schema.Types.ObjectId, ref: "Referee" }],
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: "Institute" }],
  postedSchemes: [{ type: mongoose.Schema.Types.ObjectId, ref: "Scheme" }],
  ongoingSchemes: [{ type: mongoose.Schema.Types.ObjectId, ref: "Scheme" }],
  pastSchemes: [{ type: mongoose.Schema.Types.ObjectId, ref: "Scheme" }],
});

const grantorVerificationSchema = new mongoose.Schema({
  grantorId: String,
  uniqueString: String,
  createdAt: Date,
  expiresAt: Date,
});

grantorSchema.methods.generateAuthToken = () => {
  const token = jwt.sign({ _id: this.id }, process.env.JWTPRIVATEKEY, {
    expiresIn: "30d",
  });
  return token;
};

const Grantor = mongoose.model("Grantor", grantorSchema);
const GrantorVerification = mongoose.model(
  "grantorVerification",
  grantorVerificationSchema
);

module.exports = { Grantor, GrantorVerification };
