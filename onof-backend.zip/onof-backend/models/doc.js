const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const docsSchema = new Schema({
  document: String,
  docId: String,
});

module.exports = mongoose.model("Doc", docsSchema);
