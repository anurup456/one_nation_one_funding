const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const applicationSchema = new Schema({
  applicationId: String,
  title: String,
  details: String,
  schemeName: String,
  schemeId: mongoose.Types.ObjectId,
  grantorName: String,
  grantorId: mongoose.Types.ObjectId,
  instituteName: String,
  instituteId: mongoose.Types.ObjectId,
  email: String,
  estimatedBudget: String,
  lead: String,
  document: String,
  messages: [
    {
      sender: String,
      content: String,
      time: Date,
    },
  ],
  faBadge: Boolean,
  heiBadge: Boolean,
  lastReadBy: String,
  lastSentBy: String,
  reviewer: { type: mongoose.Schema.Types.ObjectId, ref: "Referee" },
  mentor: { type: mongoose.Schema.Types.ObjectId, ref: "Referee" },
});

module.exports = mongoose.model("Application", applicationSchema);
