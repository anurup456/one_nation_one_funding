const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");

const instituteSchema = new mongoose.Schema({
  name: String,
  code: String,
  head: String,
  poc: String,
  address: String,
  email: String,
  password: String,
  emailVerified: Boolean,
  approved: Boolean,
  document: String,
  proposed: Boolean,
  following: [{ type: mongoose.Schema.Types.ObjectId, ref: "Grantor" }],
  postedApplications: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Application" },
  ],
  ongoingApplications: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Application" },
  ],
  pastApplications: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Application" },
  ],
});

const instituteVerificationSchema = new mongoose.Schema({
  instituteId: String,
  uniqueString: String,
  createdAt: Date,
  expiresAt: Date,
});

instituteSchema.methods.generateAuthToken = () => {
  const token = jwt.sign({ _id: this.id }, process.env.JWTPRIVATEKEY, {
    expiresIn: "30d",
  });
  return token;
};

const Institute = mongoose.model("Institute", instituteSchema);
const InstituteVerification = mongoose.model(
  "instituteVerification",
  instituteVerificationSchema
);

module.exports = { Institute, InstituteVerification };
