const router = require("express").Router();
const Scheme = require("../models/scheme");
const { Grantor } = require("../models/grantor");
const { Institute } = require("../models/institute");
const Application = require("../models/application");
const { transporter } = require("../transporter");
const Referee = require("../models/referee");
const Doc = require("../models/doc");
const upload = require("../middlewares/upload");

require("dotenv").config();

function generatePassword() {
  var length = 8,
    charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    retVal = "";
  for (var i = 0, n = charset.length; i < length; ++i) {
    retVal += charset.charAt(Math.floor(Math.random() * n));
  }
  return retVal;
}

router.get("/allApplications/:refereeId", async (req, res) => {
  try {
    const referee = await Referee.findOne({
      _id: req.params.refereeId,
    }).populate("applications");

    res.status(200).send(referee.applications);
  } catch (error) {
    console.log(error);
    res.status(500).send({ message: "An Error Occurred" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const referee = await Referee.findOne({ email: req.body.email });
    if (!referee) return res.status(401).send({ message: "Invalid Email!" });

    if (!referee.approved) {
      res.status(404).send({ message: "Referee Not Approved" });
    } else {
      if (req.body.password !== referee.password) {
        res.status(500).send({ message: "Invalid Password" });
      }

      const token = referee.generateAuthToken();

      res.status(200).send({
        data: token,
        message: "Logged In Successfully",
        userId: referee._id,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({ message: "Internal Server Error" });
  }
});

router.post(
  "/uploadReview/:refreeId/:applicationId",
  upload.single("file"),
  async (req, res) => {
    try {
      const doc = new Doc({
        document: req.file.filename,
        docId: req.params.refreeId + req.params.applicationId,
      });

      await doc.save();

      res.send({ message: "Review Uploaded" });
    } catch (err) {
      res.send({ message: "An Error Occurred" });
    }
  }
);

router.get("/accept/:refereeId/:grantorId", async (req, res) => {
  try {
    const referee = await Referee.findOne({ _id: req.params.refereeId });
    referee.approved = true;
    referee.save().then(async () => {
      const grantor = await Grantor.findOne({ _id: req.params.grantorId });

      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: grantor.email,
        subject: "Referee Request Accepted",
        html: `<p>Your invitation for referee was accepted by ${referee.name}.</p><p>Details:-</p><p>Institute: ${referee.institute}</p><p>Email: ${referee.email}</p><p>Designation: ${referee.designation}`,
      });

      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: referee.email,
        subject: "Login Credentials",
        html: `<p>Your Login Credentials for FundVerse are:</p><p>Email: ${referee.email}</p><p>Password: ${referee.password}</p><p>Role: Referee</p>`,
      });
    });

    res.send("Request Accepted Successfully. Check Mail for details.");
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/reject/:refereeId/:grantorId", async (req, res) => {
  try {
    const referee = await Referee.findOne({ _id: req.params.refereeId });
    referee.approved = false;
    referee.save().then(async () => {
      const grantor = await Grantor.findOne({ _id: req.params.grantorId });

      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: grantor.email,
        subject: "Referee Request Rejected.",
        html: `<p>Your invitation for referee was rejected by ${referee.name}.</p><p>Details:-</p><p>Institute: ${referee.institute}</p><p>Email: ${referee.email}</p><p>Designation: ${referee.designation}`,
      });
    });

    res.send("Request Rejected Successfully");
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/addReferee/:grantorId", async (req, res) => {
  try {
    var referee = await Referee.findOne({ email: req.body.email });

    if (!referee) {
      const all = await Referee.find();
      const len = all.length;

      referee = new Referee({
        ...req.body,
        approved: false,
        password: generatePassword(),
        refereeId: "REF" + (10001 + len),
      });

      referee.save().then(async (res) => {
        const grantor = await Grantor.findOneAndUpdate(
          { _id: req.params.grantorId },
          {
            $push: { referees: res._id },
          }
        );

        const currentUrl = "http://localhost:8080/";

        transporter.sendMail({
          from: process.env.AUTH_EMAIL,
          to: res.email,
          subject: "Referee Request",
          html: `<p>You have been invited to join ${
            grantor.name
          } as a referee for proposals.</p><p>Respond to request by clicking on the link below.</p><p><a href=${
            currentUrl + "referee/accept/" + res._id + "/" + grantor._id
          }/>Accept Request</p><p><a href=${
            currentUrl + "referee/reject/" + res._id + "/" + grantor._id
          }/>Reject Request</p>`,
        });
      });
    } else {
      const grantor = await Grantor.findOneAndUpdate(
        { _id: req.params.grantorId },
        {
          $push: { referees: referee._id },
        }
      );

      const currentUrl = "http://localhost:8080/";

      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: referee.email,
        subject: "Referee Request",
        html: `<p>You have been invited to join ${
          grantor.name
        } as a referee for proposals.</p><p>Respond to request by clicking on the link below.</p><p><a href=${
          currentUrl + "referee/accept/" + referee._id + "/" + grantor._id
        }/>Accept Request</p><p><a href=${
          currentUrl + "referee/reject/" + referee._id + "/" + grantor._id
        }/>Reject Request</p>`,
      });
    }
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }

  res.status(200).send({ message: "Request Sent to referee successfully" });
});

router.get("/all/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({
      _id: req.params.grantorId,
    }).populate("referees");

    res.status(200).send(grantor.referees);
  } catch (err) {
    console.log(err);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

module.exports = router;
