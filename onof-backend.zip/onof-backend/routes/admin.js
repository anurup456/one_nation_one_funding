const router = require("express").Router();
const { Grantor } = require("../models/grantor");
const { Institute } = require("../models/institute");
const mongoose = require("mongoose");
const Grid = require("gridfs-stream");
const { transporter } = require("../transporter");

const DB = mongoose.connection;
DB.once("open", () => {
  gridfsBucket = new mongoose.mongo.GridFSBucket(DB.db, {
    bucketName: "fs",
  });
  gfs = Grid(DB.db, mongoose.mongo);
  gfs.collection("fs");
});

router.get("/grantor/proposals", async (req, res) => {
  try {
    const grantors = await Grantor.find(
      { proposed: true },
      "name researchArea head address document email"
    );

    res.status(200).json(grantors);
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }
});

router.get("/grantor/approved", async (req, res) => {
  try {
    const grantors = await Grantor.find(
      { approved: true, emailVerified: true },
      "name researchArea head address document email"
    );

    res.status(200).json(grantors);
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }
});

router.get("/institute/proposals", async (req, res) => {
  try {
    const institutes = await Institute.find(
      { proposed: true },
      "name code head poc address document email"
    );

    res.status(200).json(institutes);
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }
});

router.get("/institute/approved", async (req, res) => {
  try {
    const institutes = await Institute.find(
      { approved: true, emailVerified: true },
      "name code head poc address document email"
    );

    res.status(200).json(institutes);
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }
});

router.get("/grantorDocs/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({ _id: req.params.grantorId });

    const file = await gfs.files.findOne({ filename: grantor.document });

    if (file) {
      const readStream = gridfsBucket.openDownloadStreamByName(file.filename);
      readStream.pipe(res);
    } else {
      res.send("No Documents Uploaded");
    }
  } catch (err) {
    console.log(err);
    res.send({ err });
  }
});

router.get("/instituteDocs/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOne({ _id: req.params.instituteId });

    const file = await gfs.files.findOne({ filename: institute.document });

    if (file) {
      const readStream = gridfsBucket.openDownloadStreamByName(file.filename);
      readStream.pipe(res);
    } else {
      res.send("No Documents Uploaded");
    }
  } catch (err) {
    console.log(err);
    res.send({ err });
  }
});

router.post("/verifyInstitute/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOneAndUpdate(
      { _id: req.params.instituteId },
      { $set: { proposed: false, approved: true } }
    );
    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: institute.email,
      subject: "Verification Successfull",
      html: `<p>Your Institute was approved by our team. Visit [site] and start applying for funding.</p>`,
    });

    res.status(200).send({ message: "Institute Verified" });
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }
});

router.post("/verifyGrantor/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOneAndUpdate(
      { _id: req.params.grantorId },
      { $set: { proposed: false, approved: true } }
    );

    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: grantor.email,
      subject: "Verification Successfull",
      html: `<p>Your organization was approved by our team. Visit [site] and start submitting your schemes.</p>`,
    });
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }

  res.status(200).send({ message: "Grantor Verified" });
});

router.post("/rejectInstitute/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOneAndUpdate(
      { _id: req.params.instituteId },
      { $set: { proposed: false, approved: false } }
    );
    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: institute.email,
      subject: "Verification unsuccessfull",
      html: `<p>Your institute was not approved by our team. Visit [site] and resubmit application</p>`,
    });

    res.status(200).send({ message: "Institute Rejected" });
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }
});

router.post("/rejectGrantor/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOneAndUpdate(
      { _id: req.params.grantorId },
      { $set: { proposed: false, approved: false } }
    );

    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: grantor.email,
      subject: "Verification unsuccessfull",
      html: `<p>Your organization was not approved by our team. Visit [site] and resubmit application</p>`,
    });
  } catch (err) {
    console.log(err);
    res.status(400).send({ message: "An Error Occurred" });
  }

  res.status(200).send({ message: "Grantor Rejected" });
});

module.exports = router;
