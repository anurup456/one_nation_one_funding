const router = require("express").Router();
const mongoose = require("mongoose");
const Scheme = require("../models/scheme");
const Grid = require("gridfs-stream");
const upload = require("../middlewares/upload");
const { Institute } = require("../models/institute");
const Application = require("../models/application");
const { transporter } = require("../transporter");
const fs = require("fs");

const DB = mongoose.connection;
DB.once("open", () => {
  gridfsBucket = new mongoose.mongo.GridFSBucket(DB.db, {
    bucketName: "fs",
  });
  gfs = Grid(DB.db, mongoose.mongo);
  gfs.collection("fs");
});

require("dotenv").config();

router.post(
  "/newApplication/:instituteId/:schemeId",
  upload.single("file"),
  async (req, res) => {
    try {
      const all = await Application.find();
      const len = all.length;

      const institute = await Institute.findOne({
        _id: req.params.instituteId,
      });
      const scheme = await Scheme.findOne({ _id: req.params.schemeId });

      var data = {
        applicationId: "APP" + (100001 + len),
        title: req.body.title,
        details: req.body.details,
        schemeId: scheme._id,
        schemeName: scheme.name,
        grantorName: scheme.grantorName,
        grantorId: scheme.grantorId,
        insituteName: institute.name,
        instituteId: institute._id,
        email: req.body.email,
        lead: req.body.lead,
        estimatedBudget: req.body.estimatedBudget,
        document: req.file ? req.file.filename : null,
      };

      const newApplication = new Application(data);
      const savedApplication = await newApplication.save();
      scheme.postedApplications.push(savedApplication._id);
      institute.postedApplications.push(savedApplication._id);
      const modS = await scheme.save();
      const modI = await institute.save();

      res.send({ msg: "New Application created successfully" });
    } catch (error) {
      console.log(error);
      res.send({ msg: "Error" });
    }
  }
);

router.get("/details/:applicationId", async (req, res) => {
  try {
    Application.findOne({
      _id: req.params.applicationId,
    }).then((data) => res.status(200).json(data));
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/postedApplications/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOne({
      _id: req.params.instituteId,
    }).populate("postedApplications");

    res.status(200).json(institute.postedApplications);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/ongoingApplications/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOne({
      _id: req.params.instituteId,
    }).populate("ongoingApplications");

    res.status(200).json(institute.ongoingApplications);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/pastApplications/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOne({
      _id: req.params.instituteId,
    }).populate("postedApplications");

    res.status(200).json(institute.postedApplications);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post(
  "/uploadFinalReview/:applicationId",
  upload.single("file"),
  async (req, res) => {
    try {
      const application = Application.findOne({
        _id: req.params.applicationId,
      });

      application.reviewDoc = req.file.filename;
      application.save();

      res.status(200).send({ message: "Review Sent Successfully" });
    } catch (err) {
      res.status(404).send({ message: "An Error Occurred" });
    }
  }
);

router.post("/acceptApplication/:applicationId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    const scheme = await Scheme.findOneAndUpdate(
      { _id: application.schemeId },
      {
        $pull: { postedApplications: application._id },
        $push: { ongoingApplications: application._id },
      }
    );

    const institute = await Institute.findOneAndUpdate(
      { _id: application.instituteId },
      {
        $pull: { postedApplications: application._id },
        $push: { ongoingApplications: application._id },
      }
    );

    if (req.file) {
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: application.email,
        subject: "Application Accepted",
        html: `<p>Your Application with name: ${application.title} was accepted by ${application.grantorName}.</p><p>Find the attached file to know more.</p><p>Visit [site] to know more.</p>`,
      });
    } else {
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: application.email,
        subject: "Application Accepted",
        html: `<p>Your Application with name: ${application.title} was accepted by ${application.grantorName}.</p><p>Visit [site] to know more.</p>`,
      });
    }

    res.status(200).send({ message: "Application Accepted" });
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/rejectApplication/:applicationId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    const scheme = await Scheme.findOneAndUpdate(
      { _id: application.schemeId },
      {
        $pull: { postedApplications: application._id },
      }
    );

    const institute = await Institute.findOneAndUpdate(
      { _id: application.instituteId },
      {
        $pull: { postedApplications: application._id },
      }
    );

    if (req.file) {
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: application.email,
        subject: "Application Accepted",
        html: `<p>Your Application with name: ${application.title} was accepted by ${application.grantorName}.</p><p>Find the attached file to know more.</p><p>Visit [site] to know more.</p>`,
      });
    } else {
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: application.email,
        subject: "Application Accepted",
        html: `<p>Your Application with name: ${application.title} was rejected by ${application.grantorName}.</p><p>Visit [site] to know more.</p>`,
      });
    }

    res.status(200).send({ message: "Application Rejected" });
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/endApplication/:applicationId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    const scheme = Scheme.findOneAndUpdate(
      { _id: application.schemeId },
      {
        $pull: { ongoingApplications: application._id },
        $push: { pastApplications: application._id },
      }
    );

    const institute = Institute.findOneAndUpdate(
      { _id: application.instituteId },
      {
        $pull: { ongoingApplications: application._id },
        $push: { pastApplications: application._id },
      }
    );

    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: application.email,
      subject: "Project Finished.",
      html: `<p>Your project with name: ${application.title} was completed and approved by ${application.grantorName}.</p><p>Visit [site] to know more.</p>`,
    });

    res.status(200).send({ message: "Project Ended Successfully" });
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

module.exports = router;
