const mongoose = require("mongoose");
const router = require("express").Router();
const Application = require("../models/application");
const upload = require("../middlewares/upload");
require("dotenv").config();

router.get("/grantor/:applicationId/:grantorId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    application.lastReadBy = "FA";
    application.faBadge = false;
    const modA = await application.save();
    res.send(application.messages);
  } catch (error) {
    console.log(error);
    res.send({
      msg: "Error",
    });
  }
});

router.get("/institute/:applicationId/:instituteId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    application.lastReadBy = "HEI";
    application.heiBadge = false;
    const modA = await application.save();
    res.send(application.messages);
  } catch (error) {
    console.log(error);
    res.send({
      msg: "Error",
    });
  }
});

router.post("/sendGrantor/:applicationId/:grantorId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    application.lastReadBy = "FA";
    application.lastSentBy = "FA";
    application.faBadge = false;
    application.heiBadge = true;

    application.messages.push({
      sender: "FA",
      content: req.body.content,
      time: Date.now(),
    });

    const modA = await application.save();
    res.send(application.messages);
  } catch (error) {
    console.log(error);
    res.send({
      msg: "Error",
    });
  }
});

router.post("/sendInstitute/:applicationId/:instituteId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    });

    application.lastReadBy = "HEI";
    application.lastSentBy = "HEI";
    application.faBadge = true;
    application.heiBadge = false;

    application.messages.push({
      sender: "HEI",
      content: req.body.content,
      time: Date.now(),
    });

    const modA = await application.save();
    res.send(application.messages);
  } catch (error) {
    console.log(error);
    res.send({
      msg: "Error",
    });
  }
});

module.exports = router;
