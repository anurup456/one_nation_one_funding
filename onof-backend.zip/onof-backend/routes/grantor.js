const mongoose = require("mongoose");
const router = require("express").Router();
const { Grantor, GrantorVerification } = require("../models/grantor");
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");
const path = require("path");
const Grid = require("gridfs-stream");
const upload = require("../middlewares/upload");
require("dotenv").config();
const { transporter } = require("../transporter");
const { Institute } = require("../models/institute");
const Referee = require("../models/referee");
const Application = require("../models/application");
const Doc = require("../models/doc");

const DB = mongoose.connection;
DB.once("open", () => {
  gridfsBucket = new mongoose.mongo.GridFSBucket(DB.db, {
    bucketName: "fs",
  });
  gfs = Grid(DB.db, mongoose.mongo);
  gfs.collection("fs");
});

const sendVerificationEmail = ({ _id, email }, res) => {
  const currentUrl = "http://localhost:8080/";

  const uniqueString = uuidv4() + _id;

  const mailOptions = {
    from: process.env.AUTH_EMAIL,
    to: email,
    subject: "Verify Your Email",
    html: `<p>Click on the Link below to verify your email.</p><p>The link expires in 6 Hours.</p><p>Click <a href=${
      currentUrl + "grantor/verify/" + _id + "/" + uniqueString
    }/> here to proceed</p>`,
  };

  const saltRounds = 10;
  bcrypt
    .hash(uniqueString, saltRounds)
    .then((hashedUniqueString) => {
      const newVerification = new GrantorVerification({
        grantorId: _id,
        uniqueString: hashedUniqueString,
        createdAt: Date.now(),
        expiresAt: Date.now() + 21600000,
      });

      newVerification
        .save()
        .then(() => {
          transporter
            .sendMail(mailOptions)
            .then(() => {
              res.json({
                status: "PENDING",
                message: "Verification Mail Sent",
              });
            })
            .catch((error) => {
              console.log(error);
              res.json({
                status: "FAILED",
                message: "An error occured",
              });
            });
        })
        .catch((error) => {
          console.log(error);
          res.json({
            status: "FAILED",
            message: "An error occured",
          });
        });
    })
    .catch(() => {
      res.json({
        status: "FAILED",
        message: "An error occurred",
      });
    });
};

router.get("/verify/:grantorId/:uniqueString", (req, res) => {
  let { grantorId, uniqueString } = req.params;
  GrantorVerification.find({ grantorId: grantorId })
    .then((result) => {
      if (result.length > 0) {
        let len = result.length;
        const { expiresAt } = result[len - 1];
        const hashedUniqueString = result[len - 1].uniqueString;
        if (expiresAt < Date.now()) {
          GrantorVerification.deleteOne({ grantorId: grantorId })
            .then((result) => {
              let message =
                "Link has expired. Please sign in again to get new link.";
              res.redirect(`/grantor/verified?error=true&message=${message}`);
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          bcrypt
            .compare(uniqueString, hashedUniqueString)
            .then((result) => {
              if (result) {
                Grantor.updateOne({ _id: grantorId }, { emailVerified: true })
                  .then(() => {
                    GrantorVerification.deleteOne({ grantorId })
                      .then(() => {
                        res.sendFile(
                          path.join(__dirname, "./../views/verified.html")
                        );
                      })
                      .catch((error) => {
                        let message = "Error occured while verifying email.";
                        res.redirect(
                          `/grantor/verified?error=true&message=${message}`
                        );
                      });
                  })
                  .catch((error) => {
                    let message = "Error occured while verifying email.";
                    res.redirect(
                      `/grantor/verified?error=true&message=${message}`
                    );
                  });
              } else {
                let message = "Error! Invalid Details";
                res.redirect(`/grantor/verified?error=true&message=${message}`);
              }
            })
            .catch((error) => {
              let message = "Error! Invalid Details";
              res.redirect(`/grantor/verified?error=true&message=${message}`);
            });
        }
      } else {
        let message =
          "Account Record Dosen't Exist or has been verified already. Please sign in or sign up to continue.";
        res.redirect(`/grantor/verified?error=true&message=${message}`);
      }
    })
    .catch((error) => {
      console.log(error);
      let message =
        "An error while checking for existing user verification record";
      res.redirect(`/grantor/verified?error=true&message=${message}`);
    });
});

router.get("/verified/", (req, res) => {
  res.sendFile(path.join(__dirname, "./../views/verified.html"));
});

router.post("/register", upload.single("file"), async (req, res) => {
  try {
    const grantor = await Grantor.findOne({ email: req.body.email });
    if (grantor)
      return res.status(409).send({ message: "Organization Already Exists" });

    const salt = await bcrypt.genSalt(Number(10));
    const hashPassword = await bcrypt.hash(req.body.password, salt);

    if (/@gmail.com\s*$/.test(req.body.email)) {
      await new Grantor({
        ...req.body,
        password: hashPassword,
        emailVerified: false,
        proposed: false,
        approved: true,
        nextId: 10001,
      })
        .save()
        .then((result) => {
          sendVerificationEmail(result, res);
        });
    } else {
      await new Grantor({
        ...req.body,
        password: hashPassword,
        emailVerified: false,
        proposed: true,
        approved: false,
        nextId: 10001,
      })
        .save()
        .then((result) => {
          transporter.sendMail({
            from: process.env.AUTH_EMAIL,
            to: process.env.AUTH_EMAIL,
            subject: "New Funding Agency Added",
            html: `<p>A New Funding Agency is looking for approval. Visit [site] to review proposal.</p><p>Name: ${result.name}</p><p>Research Area: ${result.researchArea}</p><p>Address: ${result.address}</p>`,
          });
          sendVerificationEmail(result, res);
        });
    }
  } catch (error) {
    res.status(500).send({ message: "Internal Server Error" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({ email: req.body.email });
    if (!grantor) return res.status(401).send({ message: "Invalid Email!" });

    if (!grantor.emailVerified) {
      sendVerificationEmail(grantor, res);
    } else {
      if (!grantor.approved) {
        res.status(404).send({ message: "Waiting for approval" });
      }
      const validPassword = await bcrypt.compare(
        req.body.password,
        grantor.password
      );

      if (!validPassword)
        return res.status(401).send({ message: "Invalid Password" });

      const token = grantor.generateAuthToken();

      res.status(200).send({
        data: token,
        message: "Logged In Successfully",
        userId: grantor._id,
      });
    }
  } catch (error) {
    res.status(500).send({ message: "Internal Server Error" });
  }
});

// router.post(
//   "/uploadDocs/:grantorId",
//   upload.single("file"),
//   async (req, res) => {
//     try {
//       console.log(req.file);

//       const grantor = await Grantor.findOneAndUpdate(
//         { _id: req.params.grantorId },
//         { $set: { document: req.file.filename, proposed: true } },
//         { new: true }
//       );

//       if (req.file == undefined) {
//         return res.send({
//           message: "You must select a file.",
//         });
//       }
//       transporter.sendMail({
//         from: process.env.AUTH_EMAIL,
//         to: process.env.AUTH_EMAIL,
//         subject: "New Funding Agency Added",
//         html: `<p>A New Funding Agency is looking for approval. Visit [site] to review proposal.</p><p>Name: ${result.name}</p><p>Research Area: ${result.researchArea}</p><p>Address: ${result.address}</p>`,
//       });
//       return res.json(grantor);
//     } catch (error) {
//       console.log(error);
//       return res.send({
//         message: "Error when trying upload image: ${error}",
//       });
//     }
//   }
// );
router.get("/grantorDetails/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({ _id: req.params.grantorId });

    res.status(200).json(grantor);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

router.get("/allGrantors", async (req, res) => {
  try {
    const grantors = await Grantor.find({ approved: true });

    res.status(200).json(grantors);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

router.get("/allGrantors/:search", async (req, res) => {
  try {
    const grantors = await Grantor.find({
      approved: true,
      $or: [{ name: { $regex: req.params.search, $options: "i" } }],
    });

    res.status(200).json(grantors);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

router.post("/follow/:grantorId/:instituteId", async (req, res) => {
  try {
    const grantor = await Grantor.findOneAndUpdate(
      { _id: req.params.grantorId },
      {
        $push: { followers: req.params.instituteId },
      }
    );

    const institute = await Institute.findOneAndUpdate(
      { _id: req.params.instituteId },
      {
        $push: { following: req.params.grantorId },
      }
    );

    res.status.send({ message: "Followed Successfully" });
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/removeFollow/:grantorId/:instituteId", async (req, res) => {
  try {
    const grantor = await Grantor.findOneAndUpdate(
      { _id: req.params.grantorId },
      {
        $pull: { followers: req.params.instituteId },
      }
    );

    const institute = await Institute.findOneAndUpdate(
      { _id: req.params.instituteId },
      {
        $pull: { following: req.params.grantorId },
      }
    );

    res.status.send({ message: "Unfollowed Successfully" });
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/addReferee/:applicationId", async (req, res) => {
  try {
    const refereeData = req.body.referee;
    const application = await Application.findOneAndUpdate(
      { _id: req.params.applicationId },
      {
        $set: { reviewer: refereeData },
      }
    );

    await Referee.findOneAndUpdate(
      { _id: refereeData },
      {
        $push: { applications: req.params.applicationId },
      }
    );

    res
      .status(200)
      .send({ message: "Application Sent to reviewers successfully" });

    await Referee.findOne({ _id: refereeData }).then((referee) => {
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: referee.email,
        subject: "New Application Added",
        html: `<p>A new application was added. Visit [site] to review application.</p><p>Name: ${application.title}</p><p>Added By: ${application.insituteName}</p><p>Organization: ${application.grantorName}</p>`,
      });
    });
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/addMentors/:applicationId", async (req, res) => {
  try {
    const refereesData = req.body.referees;
    const application = await Application.findOneAndUpdate(
      { _id: req.params.applicationId },
      {
        $set: { mentors: refereesData },
      }
    );

    for (var i = 0; i < refereesData.length; i++) {
      await Referee.findOneAndUpdate(
        { _id: refereesData[i] },
        {
          $push: { projects: req.params.applicationId },
        }
      );
    }

    res
      .status(200)
      .send({ message: "Application sent to mentors successfully" });

    for (var i = 0; i < refereesData.length; i++) {
      await Referee.findOne({ _id: refereesData[i] }).then((referee) => {
        transporter.sendMail({
          from: process.env.AUTH_EMAIL,
          to: referee.email,
          subject: "New Project Added",
          html: `<p>A new project was added. Visit [site] to see project updates.</p><p>Name: ${application.title}</p><p>Added By: ${application.insituteName}</p><p>Organization: ${application.grantorName}</p>`,
        });
      });
    }
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/getReferees/:applicationId", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    }).populate("reviewers");

    res.status(200).send(application.reviewers);
  } catch (err) {
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/reviewDocs/:applicationId/:refreeId", async (req, res) => {
  try {
    const doc = await Doc.findOne({
      docId: req.params.refreeId + req.params.applicationId,
    });

    const file = await gfs.files.findOne({ filename: doc.document });

    if (file) {
      const readStream = gridfsBucket.openDownloadStreamByName(file.filename);
      readStream.pipe(res);
    } else {
      res.status(500).send({ message: "No Documents Uploaded" });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({ message: "An Error Occurred" });
  }
});

router.get("/generateMeet/:applicationId/", async (req, res) => {
  try {
    const application = await Application.findOne({
      _id: req.params.applicationId,
    }).populate("reviewers");

    const grantor = await Grantor.findOne({ _id: application.grantorId });
    console.log(application);
    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: application.email,
      subject: "Application Evaluation Invitation",
      html: `<p>Your Application ${application.title} has been selected by ${
        grantor.name
      } for evaluation.</p><p>Application Id: ${
        application.applicationId
      }</p><p>Scheme Name: ${application.schemeName}</p><p>Meet Date: ${
        req.body.date
      }</p><p>Meet Time: ${
        req.body.time
      }</p><p>Join using the below link.</p><p></p><p><a href = ${"https://meet.google.com/sxu-docu-dcw"}/>Link</p>`,
    });

    transporter.sendMail({
      from: process.env.AUTH_EMAIL,
      to: grantor.email,
      subject: "Application Evaluation Invitation",
      html: `<p>Application Name: ${application.title}</p><p>Application Id: ${
        application.applicationId
      }</p><p>Scheme Name: ${application.schemeName}</p><p>Meet Date: ${
        req.body.date
      }</p><p>Meet Time: ${
        req.body.time
      }</p><p>Join using the below link.</p><p></p><p><a href = ${"https://meet.google.com/sxu-docu-dcw"}/>Link</p>`,
    });

    const reviewers = application.reviewers;
    for (var i = 0; i < reviewers.length; i++) {
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: reviewers[i].email,
        subject: "Application Evaluation Invitation",
        html: `<p>Application Name: ${
          application.title
        }</p><p>Application Id: ${
          application.applicationId
        }</p><p>Scheme Name: ${application.schemeName}</p><p>Meet Date: ${
          req.body.date
        }</p><p>Meet Time: ${
          req.body.time
        }</p><p>Join using the below link.</p><p></p><p><a href = ${"https://meet.google.com/sxu-docu-dcw"}/>Link</p>`,
      });
    }
    res.status(200).send({ message: "Meet Link Sent" });
  } catch (err) {
    console.log(err);
    res.status.send({ message: "An Error Occurred" });
  }
});

// router.get("/getReferees/:applicationId/:searchKey", async (req, res) => {
//   try {
//     const application = await Application.findOne({
//       _id: req.params.applicationId,
//     }).populate("reviewers");

//     res.status(200).send(application.reviewers);
//   } catch (err) {
//     res.status(404).send({ message: "An Error Occurred" });
//   }
// });

module.exports = router;
