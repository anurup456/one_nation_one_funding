const mongoose = require("mongoose");
const router = require("express").Router();
const { Grantor, GrantorVerification, validate } = require("../models/grantor");
const Scheme = require("../models/scheme");
const upload = require("../middlewares/upload");
const { Institute } = require("../models/institute");
require("dotenv").config();

router.post(
  "/addScheme/:grantorId",
  upload.single("file"),
  async (req, res) => {
    try {
      console.log(req.body);
      const grantor = await Grantor.findOne({
        _id: req.params.grantorId,
      });
      // .populate("followers");

      var data = {
        tags: req.body.tags.split(","),
        eligibility: req.body.eligibility.split(","),
        psID: "PS" + grantor.nextId,
        name: req.body.name,
        grantorName: grantor.name,
        grantorId: grantor._id,
        available: true,
        description: req.body.description,
        eligibility: req.body.eligibility,
        applicationDeadline: req.body.applicationDeadline,
        fundingLimit: req.body.fundingLimit,
        document: req.file ? req.file.filename : null,
      };

      const newScheme = new Scheme(data);
      const savedScheme = await newScheme.save();
      grantor.nextId = grantor.nextId + 1;
      grantor.postedSchemes.push(savedScheme._id);
      const modG = await grantor.save();

      res.status(200).send({ message: "New Scheme created successfully" });

      // grantor.followers.map((follower) => {
      //   transporter.sendMail({
      //     from: process.env.AUTH_EMAIL,
      //     to: follower.email,
      //     subject: "New Scheme Was Added",
      //     html: `<p>A New Scheme was added by ${grantor.name}. Visit [site] to view the scheme.</p><p>Name: ${newScheme.name}</p><p>Eligibility: ${newScheme.eligibility}</p><p>Application Deadline: ${newScheme.applicationDeadline}</p>`,
      //   });
      // });
    } catch (error) {
      console.log(error);
      res.status(400).send({ message: "Error!" });
    }
  }
);

router.get("/schemeDetails/:schemeId", async (req, res) => {
  try {
    const scheme = await Scheme.findOne({
      _id: req.params.schemeId,
    });

    res.status(200).json(scheme);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/postedSchemes/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({
      _id: req.params.grantorId,
    }).populate("postedSchemes postedSchemes.postedApplications");

    res.status(200).json(grantor.postedSchemes);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});
router.get("/postedSchemes/:grantorId/:search", async (req, res) => {
  try {
    const schemes = await Scheme.find({
      grantorId: req.params.grantorId,
      available: true,
      $or: [
        { name: { $regex: req.params.search, $options: "i" } },
        { grantorName: { $regex: req.params.search, $options: "i" } },
        { psID: { $regex: req.params.search, $options: "i" } },
      ],
    });

    res.status(200).json(schemes);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

router.get("/ongoingSchemes/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({
      _id: req.params.grantorId,
    }).populate("ongoingSchemes");

    res.status(200).json(grantor.ongoingSchemes);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/pastSchemes/:grantorId", async (req, res) => {
  try {
    const grantor = await Grantor.findOne({
      _id: req.params.grantorId,
    }).populate("pastSchemes");

    res.status(200).json(grantor.pastSchemes);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/allSchemes", async (req, res) => {
  try {
    const schemes = await Scheme.find({ available: true });

    res.status(200).json(schemes);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

router.get("/allSchemes/:search", async (req, res) => {
  try {
    const schemes = await Scheme.find({
      available: true,
      $or: [
        { name: { $regex: req.params.search, $options: "i" } },
        { grantorName: { $regex: req.params.search, $options: "i" } },
      ],
    });

    res.status(200).json(schemes);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

router.get("/recommendSchemes/:instituteId", async (req, res) => {
  try {
    const insitute = await Institute.findOne({ _id: req.params.instituteId });

    res.json(insitute);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.get("/postedApplications/:schemeId", async (req, res) => {
  try {
    const scheme = await Scheme.findOne({ _id: req.params.schemeId }).populate(
      "postedApplications"
    );

    res.json(scheme.postedApplications);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

router.post("/endScheme/:schemeId", async (req, res) => {
  try {
    const scheme = await Scheme.findOneAndUpdate(
      { _id: req.params.schemeId },
      { $set: { available: false } }
    );

    if (scheme.acceptedApplications.length > 0) {
      const grantor = await Grantor.findOneAndUpdate(
        { _id: scheme.grantorId },
        {
          $pull: { postedSchemes: scheme._id },
          $push: { ongoingSchemes: scheme._id },
        }
      );
    } else {
      const grantor = await Grantor.findOneAndUpdate(
        { _id: scheme.grantorId },
        {
          $pull: { postedSchemes: scheme._id },
          $push: { pastSchemes: scheme._id },
        }
      );
    }
    res.status(200).send({ message: "Scheme Removed" });
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occurred" });
  }
});

module.exports = router;
