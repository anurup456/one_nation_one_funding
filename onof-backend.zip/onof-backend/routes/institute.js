const router = require("express").Router();
const mongoose = require("mongoose");
const { Institute, InstituteVerification } = require("../models/institute");
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");
const path = require("path");
const upload = require("../middlewares/upload");
require("dotenv").config();
const Grid = require("gridfs-stream");
const { transporter } = require("../transporter");

const DB = mongoose.connection;
DB.once("open", () => {
  gridfsBucket = new mongoose.mongo.GridFSBucket(DB.db, {
    bucketName: "fs",
  });
  gfs = Grid(DB.db, mongoose.mongo);
  gfs.collection("fs");
});

const sendVerificationEmail = ({ _id, email }, res) => {
  const currentUrl = "http://localhost:8080/";

  const uniqueString = uuidv4() + _id;

  const mailOptions = {
    from: process.env.AUTH_EMAIL,
    to: email,
    subject: "Verify Your Email",
    html: `<p>Click on the Link below to verify your email.</p><p>The link expires in 6 Hours.</p><p>Click <a href=${
      currentUrl + "institute/verify/" + _id + "/" + uniqueString
    }/> here to proceed</p>`,
  };

  const saltRounds = 10;
  bcrypt
    .hash(uniqueString, saltRounds)
    .then((hashedUniqueString) => {
      const newVerification = new InstituteVerification({
        instituteId: _id,
        uniqueString: hashedUniqueString,
        createdAt: Date.now(),
        expiresAt: Date.now() + 21600000,
      });

      newVerification
        .save()
        .then(() => {
          transporter
            .sendMail(mailOptions)
            .then(() => {
              res.json({
                status: "PENDING",
                message: "Verification Mail Sent",
              });
            })
            .catch((error) => {
              console.log(error);
              res.json({
                status: "FAILED",
                message: "An error occured",
              });
            });
        })
        .catch((error) => {
          console.log(error);
          res.json({
            status: "FAILED",
            message: "An error occured",
          });
        });
    })
    .catch(() => {
      res.json({
        status: "FAILED",
        message: "An error occurred",
      });
    });
};

router.get("/verify/:instituteId/:uniqueString", (req, res) => {
  let { instituteId, uniqueString } = req.params;
  InstituteVerification.find({ instituteId: instituteId })
    .then((result) => {
      if (result.length > 0) {
        let len = result.length;
        const { expiresAt } = result[len - 1];
        const hashedUniqueString = result[len - 1].uniqueString;
        if (expiresAt < Date.now()) {
          InstituteVerification.deleteOne({ instituteId: instituteId })
            .then((result) => {
              let message =
                "Link has expired. Please sign in again to get new link.";
              res.redirect(`/institute/verified?error=true&message=${message}`);
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          bcrypt
            .compare(uniqueString, hashedUniqueString)
            .then((result) => {
              if (result) {
                Institute.updateOne(
                  { _id: instituteId },
                  { emailVerified: true }
                )
                  .then(() => {
                    InstituteVerification.deleteOne({ instituteId })
                      .then(() => {
                        res.sendFile(
                          path.join(__dirname, "./../views/verified.html")
                        );
                      })
                      .catch((error) => {
                        let message = "Error occured while verifying email.";
                        res.redirect(
                          `/institute/verified?error=true&message=${message}`
                        );
                      });
                  })
                  .catch((error) => {
                    let message = "Error occured while verifying email.";
                    res.redirect(
                      `/institute/verified?error=true&message=${message}`
                    );
                  });
              } else {
                let message = "Error! Invalid Details";
                res.redirect(
                  `/institute/verified?error=true&message=${message}`
                );
              }
            })
            .catch((error) => {
              let message = "Error! Invalid Details";
              res.redirect(`/institute/verified?error=true&message=${message}`);
            });
        }
      } else {
        let message =
          "Account Record Dosen't Exist or has been verified already. Please sign in or sign up to continue.";
        res.redirect(`/institute/verified?error=true&message=${message}`);
      }
    })
    .catch((error) => {
      console.log(error);
      let message =
        "An error while checking for existing user verification record";
      res.redirect(`/institute/verified?error=true&message=${message}`);
    });
});

router.get("/verified/", (req, res) => {
  res.sendFile(path.join(__dirname, "./../views/verified.html"));
});

router.post("/register", upload.single("file"), async (req, res) => {
  try {
    console.log(req.body);
    const institute = await Institute.findOne({ email: req.body.email });
    if (institute)
      return res.status(409).send({ message: "Institute Already Exists" });

    const salt = await bcrypt.genSalt(Number(10));
    const hashPassword = await bcrypt.hash(req.body.password, salt);

    if (/@gmail.com\s*$/.test(req.body.email)) {
      await new Institute({
        name: req.body.name,
        email: req.body.email,
        head: req.body.head,
        poc: req.body.poc,
        address: req.body.address,
        code: req.body.code,
        document: req.file.filename,
        password: hashPassword,
        emailVerified: false,
        approved: true,
        proposed: false,
      })
        .save()
        .then((result) => {
          sendVerificationEmail(result, res);
        });
    } else {
      await new Institute({
        name: req.body.name,
        email: req.body.email,
        head: req.body.head,
        poc: req.body.poc,
        address: req.body.address,
        code: req.body.code,
        document: req.file.filename,
        password: hashPassword,
        emailVerified: false,
        approved: false,
        proposed: true,
      })
        .save()
        .then((result) => {
          transporter.sendMail({
            from: process.env.AUTH_EMAIL,
            to: process.env.AUTH_EMAIL,
            subject: "New Institute Added",
            html: `<p>A New Institute is looking for approval. Visit [site] to review proposal.</p><p>Name: ${result.name}</p><p>Address: ${result.address}</p>`,
          });
          sendVerificationEmail(result, res);
        });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({ message: "Internal Server Error" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const institute = await Institute.findOne({ email: req.body.email });
    if (!institute) return res.status(401).send({ message: "Invalid Email!" });

    if (!institute.emailVerified) {
      sendVerificationEmail(institute, res);
    } else {
      if (!institute.approved) {
        res.status(404).send({ message: "Waiting for approval" });
      }
      const validPassword = await bcrypt.compare(
        req.body.password,
        institute.password
      );

      if (!validPassword)
        return res.status(401).send({ message: "Invalid Password" });

      const token = institute.generateAuthToken();

      res.status(200).send({
        data: token,
        message: "Logged In Successfully",
        userId: institute._id,
      });
    }
  } catch (error) {
    res.status(500).send({ message: "Internal Server Error" });
  }
});

router.post(
  "/uploadDocs/:instituteId",
  upload.single("file"),
  async (req, res) => {
    try {
      console.log(req.file);

      const institute = await Institute.findOneAndUpdate(
        { _id: req.params.instituteId },
        { $set: { document: req.file.filename, proposed: true } },
        { new: true }
      );

      if (req.file == undefined) {
        return res.send({
          message: "You must select a file.",
        });
      }
      transporter.sendMail({
        from: process.env.AUTH_EMAIL,
        to: process.env.AUTH_EMAIL,
        subject: "New Institute Added",
        html: `<p>A New Institute is looking for approval. Visit [site] to review proposal.</p><p>Name: ${result.name}</p><p>Code: ${result.code}</p><p>Address: ${result.address}</p>`,
      });
      return res.json(institute);
    } catch (error) {
      console.log(error);
      return res.send({
        message: "Error when trying upload image: ${error}",
      });
    }
  }
);

router.get("/instituteDetails/:instituteId", async (req, res) => {
  try {
    const institute = await Institute.findOne({ _id: req.params.instituteId });

    res.status(200).json(institute);
  } catch (error) {
    console.log(error);
    res.status(404).send({ message: "An Error Occured" });
  }
});

module.exports = router;
