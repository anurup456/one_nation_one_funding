const nodemailer = require("nodemailer");

let transporter = nodemailer.createTransport({
  service: "gmail",
  tls: {
    ciphers: "SSLv3",
    rejectUnauthorized: false,
  },
  auth: {
    user: process.env.AUTH_EMAIL,
    pass: process.env.AUTH_PASSWORD,
  },
});

try {
  transporter.verify((error, success) => {
    if (error) {
      console.log(error);
    } else {
      console.log("Transporter Ready");
    }
  });
} catch (error) {
  console.log(error);
}

module.exports = { transporter };
