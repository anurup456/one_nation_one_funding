const multer = require("multer");
require("dotenv").config();
const GridFsStorage = require("multer-gridfs-storage").GridFsStorage;

const uri = process.env.MONGO_URI;

const storage = new GridFsStorage({
  url: uri,
  options: { useNewUrlParser: true, useUnifiedTopology: true },
  file: (req, file) => {
    // const match = ["image/png", "image/jpeg"];
    const match = ["application/pdf"];

    if (match.indexOf(file.mimetype) === -1) {
      const filename = `${file.originalname}`;
      return filename;
    }

    return {
      bucketName: "fs",
      //   bucketName: "photos",
      filename: `${file.originalname}`,
    };
  },
});

module.exports = multer({ storage });
