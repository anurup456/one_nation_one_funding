module.exports = {
  secret: "onof-secret-key",
};
